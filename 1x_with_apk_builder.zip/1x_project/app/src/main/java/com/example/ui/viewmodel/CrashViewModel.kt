package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.SimulationRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.pow
import kotlin.math.round
import kotlin.random.Random

enum class CrashGamePhase {
    IDLE,
    FLYING,
    CASHED_OUT,
    CRASHED
}

enum class RoundOutcomeType {
    WIN,
    CRASHED,
    SIMULATED_FEED
}

data class CrashRoundHistoryItem(
    val roundNumber: Int,
    val crashMultiplier: Double,
    val cashedOutAt: Double?,
    val stake: Double,
    val payout: Double,
    val outcomeType: RoundOutcomeType,
    val timestamp: Long = System.currentTimeMillis()
)

data class CrashBotEntry(
    val user: String,
    val bet: Int,
    val targetOdds: Double,
    val cashedOut: Boolean = false
)

data class CrashUiState(
    val balance: Double = 0.0,
    val phase: CrashGamePhase = CrashGamePhase.IDLE,
    val multiplier: Double = 1.00,
    val crashPoint: Double = 2.50,
    val predictedCrashSeconds: Double = 4.0,
    val remainingCrashSeconds: Double = 4.0,
    val crashCountdownProgress: Float = 0f,
    val flightProgress: Float = 0f,
    val stakeInput: String = "20",
    val stakeError: String? = null,
    val isStakeValid: Boolean = true,
    val activeStake: Double = 0.0,
    val lastWinAmount: Double = 0.0,
    val statusMessage: String = "أدخل الرهان واضغط بدء المحاكاة",
    val recentCrashes: List<Double> = listOf(2.45, 11.85, 1.38, 4.12, 1.85),
    val roundHistory: List<CrashRoundHistoryItem> = initialFeedHistory(),
    val currentWinStreak: Int = 0,
    val bestCashedMultiplier: Double = 0.0,
    val bots: List<CrashBotEntry> = emptyList(),
    val showCrashPreview: Boolean = true
)

private fun initialFeedHistory(): List<CrashRoundHistoryItem> {
    val now = System.currentTimeMillis()
    val seed = listOf(2.45, 11.85, 1.38, 4.12, 1.85)
    return seed.mapIndexed { index, mult ->
        CrashRoundHistoryItem(
            roundNumber = seed.size - index,
            crashMultiplier = mult,
            cashedOutAt = null,
            stake = 0.0,
            payout = 0.0,
            outcomeType = RoundOutcomeType.SIMULATED_FEED,
            timestamp = now - (index + 1) * 45_000L
        )
    }
}

private fun generateRandomCrashPoint(): Double {
    val r = Random.nextDouble()
    val raw = when {
        r < 0.10 -> 1.05 + Random.nextDouble(0.01, 0.25)
        r < 0.58 -> 1.30 + Random.nextDouble(0.0, 1.90)
        r < 0.88 -> 3.00 + Random.nextDouble(0.0, 5.50)
        else -> 7.50 + Random.nextDouble(0.0, 14.0)
    }
    return round(raw * 100.0) / 100.0
}

private fun computeCrashDurationSeconds(targetCrash: Double): Double {
    var lo = 0.0
    var hi = 30.0
    repeat(28) {
        val mid = (lo + hi) / 2.0
        val mult = 1.0 + 0.16 * mid + 0.06 * mid.pow(2.05)
        if (mult < targetCrash) lo = mid else hi = mid
    }
    return round(((lo + hi) / 2.0) * 10.0) / 10.0
}

class CrashViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SimulationRepository(AppDatabase.getInstance(application).appDao())

    private val initialCrash = generateRandomCrashPoint()
    private val initialDuration = computeCrashDurationSeconds(initialCrash)

    private val _uiState = MutableStateFlow(
        CrashUiState(
            crashPoint = initialCrash,
            predictedCrashSeconds = initialDuration,
            remainingCrashSeconds = initialDuration,
            bots = generateBots()
        )
    )
    val uiState: StateFlow<CrashUiState> = _uiState.asStateFlow()

    private var flightJob: Job? = null

    init {
        viewModelScope.launch {
            repository.activeUser.collect { user ->
                val newBalance = user?.balance ?: 0.0
                _uiState.update { state ->
                    val validation = validateStake(state.stakeInput, newBalance, state.phase)
                    state.copy(
                        balance = newBalance,
                        stakeError = validation,
                        isStakeValid = validation == null
                    )
                }
            }
        }
    }

    private fun validateStake(input: String, balance: Double, phase: CrashGamePhase): String? {
        if (phase == CrashGamePhase.FLYING) return null
        if (input.isBlank()) return "يرجى إدخال قيمة الرهان"
        val value = input.toDoubleOrNull() ?: return "قيمة الرهان غير صالحة"
        if (value < 1.0) return "الحد الأدنى للرهان 1.00 ج.م"
        if (balance <= 0.0) return "رصيدك 0.00 ج.م — يرجى الشحن أولاً"
        if (value > balance) {
            return String.format(
                Locale.US,
                "المبلغ يتجاوز رصيدك المتاح (%.2f ج.م)",
                balance
            )
        }
        return null
    }

    private fun applyStakeInput(newInput: String) {
        _uiState.update { state ->
            val err = validateStake(newInput, state.balance, state.phase)
            state.copy(
                stakeInput = newInput,
                stakeError = err,
                isStakeValid = err == null
            )
        }
    }

    fun onStakeChange(input: String) {
        if (_uiState.value.phase == CrashGamePhase.FLYING) return
        if (input.count { it == '.' } <= 1 && input.all { it.isDigit() || it == '.' } && input.length <= 8) {
            applyStakeInput(input)
        }
    }

    fun selectQuickStake(amount: Int) {
        if (_uiState.value.phase == CrashGamePhase.FLYING) return
        applyStakeInput(amount.toString())
    }

    fun setMinStake() {
        if (_uiState.value.phase == CrashGamePhase.FLYING) return
        applyStakeInput("10")
    }

    fun setMaxStake() {
        if (_uiState.value.phase == CrashGamePhase.FLYING) return
        val maxVal = _uiState.value.balance.coerceAtLeast(0.0)
        val formatted = if (maxVal % 1.0 == 0.0) maxVal.toInt().toString() else String.format(Locale.US, "%.2f", maxVal)
        applyStakeInput(formatted)
    }

    fun halveStake() {
        if (_uiState.value.phase == CrashGamePhase.FLYING) return
        val current = _uiState.value.stakeInput.toDoubleOrNull() ?: 20.0
        val next = (current / 2.0).coerceAtLeast(1.0)
        val formatted = if (next % 1.0 == 0.0) next.toInt().toString() else String.format(Locale.US, "%.2f", next)
        applyStakeInput(formatted)
    }

    fun doubleStake() {
        if (_uiState.value.phase == CrashGamePhase.FLYING) return
        val current = _uiState.value.stakeInput.toDoubleOrNull() ?: 10.0
        val cap = _uiState.value.balance.coerceAtLeast(1.0)
        val next = (current * 2.0).coerceAtMost(cap)
        val formatted = if (next % 1.0 == 0.0) next.toInt().toString() else String.format(Locale.US, "%.2f", next)
        applyStakeInput(formatted)
    }

    fun toggleCrashPreview() {
        _uiState.update { it.copy(showCrashPreview = !it.showCrashPreview) }
    }

    fun startSimulation() {
        val current = _uiState.value
        if (current.phase == CrashGamePhase.FLYING) return

        val err = validateStake(current.stakeInput, current.balance, current.phase)
        if (err != null) {
            _uiState.update { it.copy(stakeError = err, isStakeValid = false, statusMessage = err) }
            return
        }
        val stake = current.stakeInput.toDoubleOrNull() ?: return

        viewModelScope.launch {
            val placed = repository.placeBet("Crash", stake)
            if (!placed) {
                _uiState.update {
                    it.copy(
                        stakeError = "الرصيد غير كافٍ",
                        isStakeValid = false,
                        statusMessage = "تعذر بدء الجولة، تحقق من الرصيد"
                    )
                }
                return@launch
            }

            val roundCrashPoint = current.crashPoint
            val totalDuration = computeCrashDurationSeconds(roundCrashPoint)
            val freshBots = generateBots()

            _uiState.update {
                it.copy(
                    phase = CrashGamePhase.FLYING,
                    multiplier = 1.00,
                    crashPoint = roundCrashPoint,
                    predictedCrashSeconds = totalDuration,
                    remainingCrashSeconds = totalDuration,
                    crashCountdownProgress = 0f,
                    flightProgress = 0f,
                    activeStake = stake,
                    stakeError = null,
                    isStakeValid = true,
                    lastWinAmount = 0.0,
                    bots = freshBots,
                    statusMessage = "الطائرة تحلق! اضغط Cash Out قبل انتهاء العداد"
                )
            }

            launchFlightLoop(roundCrashPoint, totalDuration)
        }
    }

    fun cashOut() {
        val current = _uiState.value
        if (current.phase != CrashGamePhase.FLYING) return

        flightJob?.cancel()
        flightJob = null

        val cashedMultiplier = current.multiplier
        val stake = current.activeStake
        val payout = round((stake * cashedMultiplier) * 100.0) / 100.0

        viewModelScope.launch {
            repository.creditWin("Crash", payout, cashedMultiplier)
        }

        val nextRoundNum = (current.roundHistory.firstOrNull()?.roundNumber ?: 0) + 1
        val entry = CrashRoundHistoryItem(
            roundNumber = nextRoundNum,
            crashMultiplier = current.crashPoint,
            cashedOutAt = cashedMultiplier,
            stake = stake,
            payout = payout,
            outcomeType = RoundOutcomeType.WIN
        )

        val upcomingCrash = generateRandomCrashPoint()
        val upcomingDuration = computeCrashDurationSeconds(upcomingCrash)

        _uiState.update { state ->
            state.copy(
                phase = CrashGamePhase.CASHED_OUT,
                lastWinAmount = payout,
                activeStake = 0.0,
                crashPoint = upcomingCrash,
                predictedCrashSeconds = upcomingDuration,
                remainingCrashSeconds = upcomingDuration,
                crashCountdownProgress = 0f,
                recentCrashes = (listOf(current.crashPoint) + state.recentCrashes).take(12),
                roundHistory = (listOf(entry) + state.roundHistory).take(40),
                currentWinStreak = state.currentWinStreak + 1,
                bestCashedMultiplier = maxOf(state.bestCashedMultiplier, cashedMultiplier),
                statusMessage = String.format(
                    Locale.US,
                    "توقفت بنجاح عند %.2fx • ربحت +%.2f ج.م",
                    cashedMultiplier,
                    payout
                )
            )
        }
    }

    private fun launchFlightLoop(targetCrash: Double, totalDurationSec: Double) {
        flightJob?.cancel()
        flightJob = viewModelScope.launch {
            val startMs = System.currentTimeMillis()
            while (true) {
                val elapsedSec = (System.currentTimeMillis() - startMs) / 1000.0
                val rawMultiplier = 1.0 + 0.16 * elapsedSec + 0.06 * elapsedSec.pow(2.05)
                val roundedMultiplier = round(rawMultiplier * 100.0) / 100.0

                if (roundedMultiplier >= targetCrash) {
                    val upcomingCrash = generateRandomCrashPoint()
                    val upcomingDuration = computeCrashDurationSeconds(upcomingCrash)

                    _uiState.update { state ->
                        val nextRoundNum = (state.roundHistory.firstOrNull()?.roundNumber ?: 0) + 1
                        val entry = CrashRoundHistoryItem(
                            roundNumber = nextRoundNum,
                            crashMultiplier = targetCrash,
                            cashedOutAt = null,
                            stake = state.activeStake,
                            payout = 0.0,
                            outcomeType = RoundOutcomeType.CRASHED
                        )
                        val err = validateStake(state.stakeInput, state.balance, CrashGamePhase.CRASHED)
                        state.copy(
                            phase = CrashGamePhase.CRASHED,
                            multiplier = targetCrash,
                            activeStake = 0.0,
                            crashPoint = upcomingCrash,
                            predictedCrashSeconds = upcomingDuration,
                            remainingCrashSeconds = upcomingDuration,
                            crashCountdownProgress = 0f,
                            stakeError = err,
                            isStakeValid = err == null,
                            recentCrashes = (listOf(targetCrash) + state.recentCrashes).take(12),
                            roundHistory = (listOf(entry) + state.roundHistory).take(40),
                            currentWinStreak = 0,
                            statusMessage = String.format(
                                Locale.US,
                                "انفجرت الطائرة عند %.2fx!",
                                targetCrash
                            )
                        )
                    }
                    break
                } else {
                    val progress = ((elapsedSec / 8.5).toFloat()).coerceIn(0f, 0.96f)
                    val remaining = (totalDurationSec - elapsedSec).coerceAtLeast(0.0)
                    val countdownProgress = if (totalDurationSec > 0.0) {
                        (elapsedSec / totalDurationSec).toFloat().coerceIn(0f, 1f)
                    } else 0f

                    _uiState.update { state ->
                        state.copy(
                            multiplier = roundedMultiplier,
                            flightProgress = progress,
                            remainingCrashSeconds = round(remaining * 10.0) / 10.0,
                            crashCountdownProgress = countdownProgress,
                            bots = state.bots.map { bot ->
                                if (!bot.cashedOut && roundedMultiplier >= bot.targetOdds) {
                                    bot.copy(cashedOut = true)
                                } else {
                                    bot
                                }
                            }
                        )
                    }
                }
                delay(40)
            }
        }
    }

    private fun generateBots(): List<CrashBotEntry> {
        val names = listOf("DevX", "Mido_99", "Capt2024", "Dev77", "User2024", "EagleVIP", "Shadow77", "Ahmed01")
        val bets = listOf(1000, 500, 200, 100, 50)
        return names.map { name ->
            CrashBotEntry(
                user = name,
                bet = bets.random(),
                targetOdds = (115..780).random() / 100.0
            )
        }
    }

    override fun onCleared() {
        flightJob?.cancel()
        super.onCleared()
    }
}
