package com.example.ui.screens.games

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GameTopBar
import com.example.ui.components.QuickStakeControlPanel
import com.example.ui.components.formatEgp
import com.example.ui.theme.CrimsonLoss
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.SkyActionBlue
import kotlinx.coroutines.launch
import kotlin.random.Random

private val MundialSteps = listOf(1.92, 3.84, 7.68, 15.36, 30.7, 57.0)

@Composable
fun MundialScreen(
    balance: Double,
    onPlaceBet: suspend (String, Double) -> Boolean,
    onCreditWin: (String, Double, Double) -> Unit,
    onNavigateDeposit: () -> Unit,
    onBack: () -> Unit
) {
    var stakeText by remember { mutableStateOf("20") }
    var isPlaying by remember { mutableStateOf(false) }
    var activeStake by remember { mutableDoubleStateOf(0.0) }
    var goalsScored by remember { mutableIntStateOf(0) }
    var lastShotZone by remember { mutableIntStateOf(-1) }
    var keeperZone by remember { mutableIntStateOf(-1) }
    var statusText by remember { mutableStateOf("اضغط STAKE ثم اختر زاوية التسديد!") }
    val scope = rememberCoroutineScope()

    fun startRound() {
        val stake = stakeText.toDoubleOrNull() ?: 0.0
        if (stake <= 0.0 || stake > balance) {
            statusText = "الرصيد غير كافٍ"
            return
        }
        scope.launch {
            if (onPlaceBet("Mundial", stake)) {
                activeStake = stake
                goalsScored = 0
                lastShotZone = -1
                keeperZone = -1
                isPlaying = true
                statusText = "سدد نحو إحدى الزوايا الثلاث!"
            }
        }
    }

    fun cashout() {
        if (!isPlaying || goalsScored == 0) return
        val mult = MundialSteps[goalsScored - 1]
        val payout = activeStake * mult
        onCreditWin("Mundial", payout, mult)
        statusText = "هدف الفوز! ربحت +${formatEgp(payout)} ج.م"
        isPlaying = false
        activeStake = 0.0
    }

    fun shoot(zone: Int) {
        if (!isPlaying) return
        val keeper = Random.nextInt(3)
        lastShotZone = zone
        keeperZone = keeper
        if (zone == keeper) {
            isPlaying = false
            activeStake = 0.0
            statusText = "تصدى لها الحارس! حاول مجدداً"
        } else {
            goalsScored++
            if (goalsScored >= MundialSteps.size) {
                cashout()
            } else {
                statusText = "جووول! المضاعف الآن x${MundialSteps[goalsScored - 1]}"
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0A3A66), Color(0xFF1565C0), Color(0xFF1B5E20))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        GameTopBar(
            balance = balance,
            onBack = onBack,
            onAddFunds = onNavigateDeposit,
            title = "Mundial",
            darkTheme = true
        )

        // Multiplier ladder bar
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MundialSteps.forEachIndexed { idx, mult ->
                    val achieved = goalsScored > idx
                    val nextTarget = isPlaying && goalsScored == idx
                    Surface(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        color = when {
                            achieved -> EmeraldBright
                            nextTarget -> GoldAccent
                            else -> Color.Black.copy(alpha = 0.35f)
                        }
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "x$mult",
                                style = TextStyle(
                                    fontFamily = OutfitFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                ),
                                color = if (nextTarget) Color.Black else Color.White
                            )
                        }
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Goal Frame with 3 targets
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp),
                shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 6.dp, bottomEnd = 6.dp),
                color = Color.White.copy(alpha = 0.1f),
                border = BorderStroke(4.dp, Color.White)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Net lines
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val cols = 10
                        val rows = 6
                        for (i in 1 until cols) {
                            val x = size.width * i / cols
                            drawLine(Color.White.copy(alpha = 0.15f), Offset(x, 0f), Offset(x, size.height), 1.5f)
                        }
                        for (j in 1 until rows) {
                            val y = size.height * j / rows
                            drawLine(Color.White.copy(alpha = 0.15f), Offset(0f, y), Offset(size.width, y), 1.5f)
                        }
                    }

                    val labels = listOf("يمين", "وسط", "يسار")
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (z in 0..2) {
                            val isKeeperHere = keeperZone == z
                            val isBallHere = lastShotZone == z
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(124.dp)
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable(enabled = isPlaying) { shoot(z) },
                                shape = RoundedCornerShape(16.dp),
                                color = when {
                                    isKeeperHere && isBallHere -> CrimsonLoss.copy(alpha = 0.65f)
                                    isBallHere -> EmeraldBright.copy(alpha = 0.65f)
                                    isPlaying -> Color.White.copy(alpha = 0.2f)
                                    else -> Color.White.copy(alpha = 0.08f)
                                },
                                border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.45f))
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    if (isBallHere) {
                                        Icon(
                                            imageVector = Icons.Default.SportsSoccer,
                                            contentDescription = "كرة",
                                            tint = Color.White,
                                            modifier = Modifier.size(34.dp)
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(Color.White.copy(alpha = 0.35f))
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = if (isKeeperHere) "الحارس" else labels[z],
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelLarge
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = statusText,
                style = MaterialTheme.typography.titleMedium,
                color = GoldAccent
            )
        }

        val canCashout = isPlaying && goalsScored > 0
        val currentWin = if (canCashout) activeStake * MundialSteps[goalsScored - 1] else 0.0
        QuickStakeControlPanel(
            stakeText = stakeText,
            onStakeChange = { stakeText = it },
            balance = balance,
            enabled = !isPlaying,
            primaryButtonText = when {
                canCashout -> "TAKE ${formatEgp(currentWin)}"
                isPlaying -> "سدد الكرة"
                else -> "STAKE"
            },
            primaryButtonColor = if (canCashout) EmeraldBright else SkyActionBlue,
            onPrimaryClick = {
                if (canCashout) cashout() else if (!isPlaying) startRound()
            }
        )
    }
}
