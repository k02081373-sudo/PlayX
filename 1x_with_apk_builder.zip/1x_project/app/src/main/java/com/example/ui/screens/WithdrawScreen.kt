package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.WalletResult
import com.example.ui.components.LtrNumberText
import com.example.ui.components.SimulationNoticePill
import com.example.ui.components.formatEgp
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.LobbyBackground
import com.example.ui.theme.NavyBrand
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.TextDarkPrimary
import com.example.ui.theme.TextDarkSecondary
import com.example.ui.theme.WithdrawPurple

@Composable
fun WithdrawScreen(
    balance: Double,
    walletFeedback: WalletResult?,
    onConfirmWithdraw: (String, String) -> Unit,
    onClearFeedback: () -> Unit,
    onBack: () -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var phoneText by remember { mutableStateOf("") }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(walletFeedback) {
        if (walletFeedback != null) {
            val msg = when (walletFeedback) {
                is WalletResult.Success -> {
                    amountText = ""
                    walletFeedback.message
                }
                is WalletResult.Error -> walletFeedback.message
            }
            snackbarHostState.showSnackbar(msg)
            onClearFeedback()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = LobbyBackground,
        topBar = {
            Surface(color = Color.White, shadowElevation = 2.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("withdraw_back_button")
                    ) {
                        Text(
                            text = "رجوع",
                            style = MaterialTheme.typography.titleMedium,
                            color = NavyBrand
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "رجوع",
                            tint = NavyBrand
                        )
                    }
                    Text(
                        text = "طلب سحب أموال",
                        style = MaterialTheme.typography.titleLarge,
                        color = NavyBrand
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SimulationNoticePill()

            // Green Balance Banner matching Screenshot 2
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = EmeraldBright,
                shadowElevation = 4.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 22.dp, horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "الرصيد المتاح حالياً",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White.copy(alpha = 0.92f)
                    )
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        LtrNumberText(
                            text = formatEgp(balance),
                            style = TextStyle(
                                fontFamily = OutfitFontFamily,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 30.sp
                            ),
                            color = Color.White
                        )
                        Text(
                            text = "جنيه",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                }
            }

            // Form Card matching Screenshot 2
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = Color.White,
                shadowElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "المبلغ المطلوب سحبه",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextDarkPrimary
                    )

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { input ->
                            if (input.all { it.isDigit() || it == '.' }) {
                                amountText = input
                            }
                        },
                        placeholder = {
                            Text(
                                "أدخل المبلغ بالجنيه",
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("withdraw_amount_input")
                    )

                    Text(
                        text = "رقم المحفظة التجريبي (فودافون كاش، إلخ)",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextDarkPrimary
                    )

                    OutlinedTextField(
                        value = phoneText,
                        onValueChange = { input ->
                            if (input.all { it.isDigit() } && input.length <= 15) {
                                phoneText = input
                            }
                        },
                        placeholder = {
                            Text(
                                "أدخل رقم الهاتف للسحب التجريبي",
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("withdraw_phone_input")
                    )

                    Text(
                        text = "الحد الأدنى للسحب: 50 جنيه",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextDarkSecondary
                    )
                }
            }

            Button(
                onClick = { onConfirmWithdraw(amountText, phoneText) },
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = WithdrawPurple),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("withdraw_confirm_button")
            ) {
                Text(
                    text = "تأكيد طلب السحب (محاكاة)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Text(
                text = "ملاحظة: جميع عمليات السحب والإيداع هي محاكاة للتسلية فقط ولا تتضمن أموالاً حقيقية.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextDarkSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }
    }
}
