package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TransactionEntity
import com.example.data.TransactionType
import com.example.ui.components.LtrNumberText
import com.example.ui.components.formatEgp
import com.example.ui.theme.CrimsonLoss
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.LobbyBackground
import com.example.ui.theme.NavyBrand
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.SkyActionBlue
import com.example.ui.theme.TextDarkPrimary
import com.example.ui.theme.TextDarkSecondary
import com.example.ui.theme.WithdrawPurple
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class HistoryFilter(val label: String) {
    ALL("الكل"),
    WALLET("الإيداع والسحب"),
    GAMES("الألعاب")
}

@Composable
fun HistoryScreen(
    transactions: List<TransactionEntity>,
    onClaimRefill: () -> Unit,
    onBack: () -> Unit
) {
    var filter by remember { mutableStateOf(HistoryFilter.ALL) }
    val filtered = remember(transactions, filter) {
        when (filter) {
            HistoryFilter.ALL -> transactions
            HistoryFilter.WALLET -> transactions.filter {
                it.type == TransactionType.DEPOSIT || it.type == TransactionType.WITHDRAW || it.type == TransactionType.BONUS
            }
            HistoryFilter.GAMES -> transactions.filter {
                it.type == TransactionType.BET || it.type == TransactionType.WIN
            }
        }
    }

    Scaffold(
        containerColor = LobbyBackground,
        topBar = {
            Surface(color = Color.White, shadowElevation = 2.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = onBack) {
                        Text("رجوع", style = MaterialTheme.typography.titleMedium, color = NavyBrand)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "رجوع",
                            tint = NavyBrand
                        )
                    }
                    Text(
                        text = "سجل المحاكاة",
                        style = MaterialTheme.typography.titleLarge,
                        color = NavyBrand
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HistoryFilter.entries.forEach { option ->
                        FilterChip(
                            selected = filter == option,
                            onClick = { filter = option },
                            label = { Text(option.label) }
                        )
                    }
                }
            }

            Button(
                onClick = onClaimRefill,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Icon(Icons.Default.AddCircleOutline, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("شحن رصيد مجاني (+500 ج.م)", fontWeight = FontWeight.Bold, color = Color.White)
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (filtered.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = null,
                            tint = TextDarkSecondary,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "لا توجد عمليات في هذا التصنيف بعد",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextDarkSecondary
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filtered, key = { it.id }) { tx ->
                        TransactionCard(tx)
                    }
                }
            }
        }
    }
}

@Composable
private fun TransactionCard(tx: TransactionEntity) {
    val isPositive = tx.amount >= 0
    val accent = when (tx.type) {
        TransactionType.DEPOSIT -> EmeraldSuccess
        TransactionType.WIN -> EmeraldSuccess
        TransactionType.BONUS -> SkyActionBlue
        TransactionType.WITHDRAW -> WithdrawPurple
        TransactionType.BET -> CrimsonLoss
    }
    val icon = when (tx.type) {
        TransactionType.DEPOSIT -> Icons.Default.ArrowDownward
        TransactionType.WITHDRAW -> Icons.Default.ArrowUpward
        TransactionType.WIN -> Icons.Default.EmojiEvents
        TransactionType.BET -> Icons.Default.SportsEsports
        TransactionType.BONUS -> Icons.Default.CardGiftcard
    }
    val dateStr = remember(tx.timestamp) {
        SimpleDateFormat("MM/dd HH:mm", Locale.US).format(Date(tx.timestamp))
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        shadowElevation = 1.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = accent.copy(alpha = 0.14f),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(22.dp))
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tx.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = TextDarkPrimary
                )
                Text(
                    text = "${tx.methodOrGame} • ${tx.details}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextDarkSecondary
                )
                Text(
                    text = "$dateStr • ${tx.status}",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextDarkSecondary
                )
            }

            LtrNumberText(
                text = (if (isPositive) "+" else "") + formatEgp(tx.amount) + " ج.م",
                style = TextStyle(
                    fontFamily = OutfitFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                ),
                color = if (isPositive) EmeraldSuccess else CrimsonLoss
            )
        }
    }
}
