package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PlayXLightColorScheme = lightColorScheme(
    primary = SkyActionBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD6EEFF),
    onPrimaryContainer = NavyBrand,
    secondary = DeepRoyalBlue,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0EBFF),
    onSecondaryContainer = NavyBrand,
    tertiary = WithdrawPurple,
    onTertiary = Color.White,
    background = LobbyBackground,
    onBackground = TextDarkPrimary,
    surface = LobbySurface,
    onSurface = TextDarkPrimary,
    surfaceVariant = Color(0xFFE7ECF4),
    onSurfaceVariant = TextDarkSecondary,
    error = CrimsonLoss,
    onError = Color.White
)

@Composable
fun PlayXTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PlayXLightColorScheme,
        typography = PlayXTypography,
        content = content
    )
}
