package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AuthResult
import com.example.data.SimulationRepository
import com.example.data.TransactionEntity
import com.example.data.UserEntity
import com.example.data.WalletResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface SessionState {
    data object Loading : SessionState
    data object Unauthenticated : SessionState
    data class Authenticated(val user: UserEntity) : SessionState
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SimulationRepository(AppDatabase.getInstance(application).appDao())

    val sessionState: StateFlow<SessionState> = repository.activeUser
        .map { user ->
            if (user == null) SessionState.Unauthenticated else SessionState.Authenticated(user)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = SessionState.Loading
        )

    val activeUser: StateFlow<UserEntity?> = repository.activeUser
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val transactions: StateFlow<List<TransactionEntity>> = repository.transactions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _walletFeedback = MutableStateFlow<WalletResult?>(null)
    val walletFeedback: StateFlow<WalletResult?> = _walletFeedback.asStateFlow()

    fun clearAuthError() {
        _authError.value = null
    }

    fun clearWalletFeedback() {
        _walletFeedback.value = null
    }

    fun login(identifier: String, password: String) {
        viewModelScope.launch {
            _authError.value = null
            when (val res = repository.login(identifier, password)) {
                is AuthResult.Success -> Unit
                is AuthResult.Error -> _authError.value = res.message
            }
        }
    }

    fun register(displayName: String, username: String, email: String, password: String) {
        viewModelScope.launch {
            _authError.value = null
            when (val res = repository.register(displayName, username, email, password)) {
                is AuthResult.Success -> Unit
                is AuthResult.Error -> _authError.value = res.message
            }
        }
    }

    fun quickDemoLogin() {
        viewModelScope.launch {
            _authError.value = null
            repository.quickDemoLogin()
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    fun simulateDeposit(method: String, amountText: String) {
        val amount = amountText.toDoubleOrNull()
        if (amount == null) {
            _walletFeedback.value = WalletResult.Error("يرجى إدخال مبلغ صحيح")
            return
        }
        viewModelScope.launch {
            _walletFeedback.value = repository.simulateDeposit(method, amount)
        }
    }

    fun simulateWithdraw(amountText: String, walletPhone: String) {
        val amount = amountText.toDoubleOrNull()
        if (amount == null) {
            _walletFeedback.value = WalletResult.Error("يرجى إدخال مبلغ صحيح")
            return
        }
        viewModelScope.launch {
            _walletFeedback.value = repository.simulateWithdraw(amount, walletPhone)
        }
    }

    fun claimFreeRefill() {
        viewModelScope.launch {
            _walletFeedback.value = repository.claimFreeRefill()
        }
    }

    suspend fun placeBet(gameName: String, stake: Double): Boolean {
        return repository.placeBet(gameName, stake)
    }

    fun creditWin(gameName: String, payout: Double, multiplier: Double) {
        viewModelScope.launch {
            repository.creditWin(gameName, payout, multiplier)
        }
    }
}
