package com.example.ui.screens.games

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GameTopBar
import com.example.ui.components.QuickStakeControlPanel
import com.example.ui.components.formatEgp
import com.example.ui.theme.CrimsonLoss
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.ForestDarkBg
import com.example.ui.theme.ForestMidBg
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.SkyActionBlue
import com.example.ui.theme.WoodTileBase
import com.example.ui.theme.WoodTileRim
import kotlinx.coroutines.launch
import kotlin.random.Random

private val AppleMultipliers = listOf(1.23, 1.54, 1.93, 2.41, 4.33, 8.66, 17.3, 34.6, 69.3, 138.6)

private enum class AppleTileReveal { HIDDEN, FRESH_APPLE, ROTTEN_APPLE }

@Composable
fun AppleOfFortuneScreen(
    balance: Double,
    onPlaceBet: suspend (String, Double) -> Boolean,
    onCreditWin: (String, Double, Double) -> Unit,
    onNavigateDeposit: () -> Unit,
    onBack: () -> Unit
) {
    var stakeText by remember { mutableStateOf("20") }
    var isPlaying by remember { mutableStateOf(false) }
    var activeStake by remember { mutableDoubleStateOf(0.0) }
    var currentRow by remember { mutableIntStateOf(0) } // 0 is bottom row
    var wonRowsCount by remember { mutableIntStateOf(0) }
    var statusBanner by remember { mutableStateOf<String?>(null) }

    // Map of Pair(row, col) -> reveal state
    val revealedTiles = remember { mutableStateMapOf<Pair<Int, Int>, AppleTileReveal>() }
    val rottenColPerRow = remember { mutableStateMapOf<Int, List<Int>>() }
    val scope = rememberCoroutineScope()

    fun startNewRound() {
        val stake = stakeText.toDoubleOrNull() ?: 0.0
        if (stake <= 0.0 || stake > balance) {
            statusBanner = "الرصيد غير كافٍ"
            return
        }
        scope.launch {
            if (onPlaceBet("Apple Of Fortune", stake)) {
                revealedTiles.clear()
                rottenColPerRow.clear()
                for (r in 0..9) {
                    val rottenCount = when {
                        r < 4 -> 1
                        r < 7 -> 2
                        else -> 3
                    }
                    rottenColPerRow[r] = (0..4).shuffled().take(rottenCount)
                }
                activeStake = stake
                currentRow = 0
                wonRowsCount = 0
                isPlaying = true
                statusBanner = null
            }
        }
    }

    fun takeWin() {
        if (!isPlaying || wonRowsCount == 0) return
        val mult = AppleMultipliers[wonRowsCount - 1]
        val payout = activeStake * mult
        onCreditWin("Apple Of Fortune", payout, mult)
        statusBanner = "مبروك! ربحت ${formatEgp(payout)} ج.م (x$mult)"
        isPlaying = false
        activeStake = 0.0
    }

    fun pickTile(row: Int, col: Int) {
        if (!isPlaying || row != currentRow) return
        val badCols = rottenColPerRow[row] ?: listOf(Random.nextInt(5))
        if (col in badCols) {
            // Reveal all in row and end round
            for (c in 0..4) {
                revealedTiles[row to c] =
                    if (c in badCols) AppleTileReveal.ROTTEN_APPLE else AppleTileReveal.FRESH_APPLE
            }
            isPlaying = false
            activeStake = 0.0
            statusBanner = "تفاحة فاسدة! انتهت الجولة"
        } else {
            revealedTiles[row to col] = AppleTileReveal.FRESH_APPLE
            wonRowsCount = row + 1
            if (row == 9) {
                takeWin()
            } else {
                currentRow = row + 1
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(ForestDarkBg, ForestMidBg, ForestDarkBg)
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            GameTopBar(
                balance = balance,
                onBack = onBack,
                onAddFunds = onNavigateDeposit,
                title = "Apple Of Fortune",
                darkTheme = true
            )

            statusBanner?.let { msg ->
                Surface(
                    color = Color.Black.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(bottom = 4.dp)
                ) {
                    Text(
                        text = msg,
                        color = GoldAccent,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
            }

            // 10 Rows x 5 Cols + Multiplier Ladder matching Screenshot 6
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.SpaceEvenly
                ) {
                    for (row in 9 downTo 0) {
                        val isRowActive = isPlaying && row == currentRow
                        val multLabel = "x${AppleMultipliers[row]}"
                        val isRowCleared = wonRowsCount > row

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // 5 wooden tiles
                            Row(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                for (col in 0..4) {
                                    val reveal = revealedTiles[row to col] ?: AppleTileReveal.HIDDEN
                                    WoodenMedallionTile(
                                        reveal = reveal,
                                        isActiveRow = isRowActive,
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                            .clickable(enabled = isRowActive) { pickTile(row, col) }
                                    )
                                }
                            }

                            // Multiplier Pill on Right
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = when {
                                    isRowActive -> EmeraldBright
                                    isRowCleared -> Color(0xFF43A047).copy(alpha = 0.8f)
                                    else -> Color.White.copy(alpha = 0.14f)
                                },
                                modifier = Modifier
                                    .size(width = 62.dp, height = 34.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = multLabel,
                                        style = TextStyle(
                                            fontFamily = OutfitFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        ),
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            val canTakeWin = isPlaying && wonRowsCount > 0
            val currentWinAmount = if (canTakeWin) activeStake * AppleMultipliers[wonRowsCount - 1] else 0.0

            QuickStakeControlPanel(
                stakeText = stakeText,
                onStakeChange = { stakeText = it },
                balance = balance,
                enabled = !isPlaying,
                primaryButtonText = when {
                    canTakeWin -> "TAKE ${formatEgp(currentWinAmount)}"
                    isPlaying -> "اختر تفاحة"
                    else -> "STAKE"
                },
                primaryButtonColor = if (canTakeWin) EmeraldBright else SkyActionBlue,
                onPrimaryClick = {
                    if (canTakeWin) takeWin() else if (!isPlaying) startNewRound()
                }
            )
        }
    }
}

@Composable
private fun WoodenMedallionTile(
    reveal: AppleTileReveal,
    isActiveRow: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = if (isActiveRow) listOf(Color(0xFFC2723B), WoodTileBase)
                    else listOf(WoodTileBase, WoodTileRim)
                )
            )
            .border(
                BorderStroke(
                    width = if (isActiveRow) 2.dp else 1.5.dp,
                    color = if (isActiveRow) GoldAccent else Color(0xFF3E1C0A)
                ),
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        when (reveal) {
            AppleTileReveal.HIDDEN -> {
                if (isActiveRow) {
                    // Golden glow ring cue
                    Canvas(modifier = Modifier.fillMaxSize(0.56f)) {
                        drawCircle(
                            color = GoldAccent.copy(alpha = 0.85f),
                            radius = size.minDimension * 0.42f
                        )
                        drawCircle(
                            color = Color(0xFFFF8F00),
                            radius = size.minDimension * 0.25f
                        )
                    }
                }
            }
            AppleTileReveal.FRESH_APPLE -> {
                Canvas(modifier = Modifier.fillMaxSize(0.68f)) {
                    val r = size.minDimension * 0.44f
                    val c = Offset(size.width / 2f, size.height * 0.56f)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFFFF5252), Color(0xFFD50000)),
                            center = Offset(c.x - r * 0.3f, c.y - r * 0.3f)
                        ),
                        radius = r,
                        center = c
                    )
                    val leaf = Path().apply {
                        moveTo(c.x, c.y - r * 0.9f)
                        quadraticTo(c.x + r * 0.6f, c.y - r * 1.4f, c.x + r * 0.65f, c.y - r * 0.8f)
                        close()
                    }
                    drawPath(leaf, color = EmeraldBright)
                }
            }
            AppleTileReveal.ROTTEN_APPLE -> {
                Canvas(modifier = Modifier.fillMaxSize(0.68f)) {
                    val r = size.minDimension * 0.42f
                    val c = Offset(size.width / 2f, size.height * 0.54f)
                    drawCircle(color = Color(0xFF5D4037), radius = r, center = c)
                    drawCircle(color = CrimsonLoss, radius = r * 0.3f, center = Offset(c.x + r * 0.2f, c.y - r * 0.1f))
                }
            }
        }
    }
}
