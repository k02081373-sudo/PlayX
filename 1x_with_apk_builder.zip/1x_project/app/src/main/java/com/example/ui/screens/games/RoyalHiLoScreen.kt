package com.example.ui.screens.games

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GameTopBar
import com.example.ui.components.LtrNumberText
import com.example.ui.components.QuickStakeControlPanel
import com.example.ui.components.formatEgp
import com.example.ui.theme.CrimsonLoss
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.SkyActionBlue
import kotlinx.coroutines.launch
import kotlin.random.Random

private data class PlayingCard(val rank: Int, val suit: String, val isRed: Boolean) {
    val rankLabel: String
        get() = when (rank) {
            1 -> "A"
            11 -> "J"
            12 -> "Q"
            13 -> "K"
            else -> rank.toString()
        }
}

private fun randomCard(): PlayingCard {
    val rank = Random.nextInt(1, 14)
    val suits = listOf("♠" to false, "♥" to true, "♦" to true, "♣" to false)
    val (s, red) = suits.random()
    return PlayingCard(rank, s, red)
}

@Composable
fun RoyalHiLoScreen(
    balance: Double,
    onPlaceBet: suspend (String, Double) -> Boolean,
    onCreditWin: (String, Double, Double) -> Unit,
    onNavigateDeposit: () -> Unit,
    onBack: () -> Unit
) {
    var stakeText by remember { mutableStateOf("20") }
    var isPlaying by remember { mutableStateOf(false) }
    var activeStake by remember { mutableDoubleStateOf(0.0) }
    var currentCard by remember { mutableStateOf(randomCard()) }
    var multiplier by remember { mutableDoubleStateOf(1.0) }
    var streak by remember { mutableIntStateOf(0) }
    var statusText by remember { mutableStateOf("اضغط STAKE وتوقّع الورقة القادمة") }
    val scope = rememberCoroutineScope()

    val higherChance = ((13 - currentCard.rank).coerceAtLeast(1) / 13.0)
    val lowerChance = ((currentCard.rank - 1).coerceAtLeast(1) / 13.0)
    val higherOdds = (kotlin.math.round((0.94 / higherChance) * 100.0) / 100.0).coerceIn(1.12, 6.0)
    val lowerOdds = (kotlin.math.round((0.94 / lowerChance) * 100.0) / 100.0).coerceIn(1.12, 6.0)

    fun startRound() {
        val stake = stakeText.toDoubleOrNull() ?: 0.0
        if (stake <= 0.0 || stake > balance) {
            statusText = "الرصيد غير كافٍ"
            return
        }
        scope.launch {
            if (onPlaceBet("Royal Hi-Lo", stake)) {
                currentCard = randomCard()
                activeStake = stake
                multiplier = 1.0
                streak = 0
                isPlaying = true
                statusText = "هل الورقة التالية أعلى أم أقل؟"
            }
        }
    }

    fun cashout() {
        if (!isPlaying || streak == 0) return
        val payout = activeStake * multiplier
        onCreditWin("Royal Hi-Lo", payout, multiplier)
        statusText = "تم السحب! +${formatEgp(payout)} ج.م"
        isPlaying = false
        activeStake = 0.0
    }

    fun guess(pickHigher: Boolean) {
        if (!isPlaying) return
        val next = randomCard()
        val won = if (pickHigher) next.rank >= currentCard.rank else next.rank <= currentCard.rank
        val stepOdds = if (pickHigher) higherOdds else lowerOdds
        currentCard = next
        if (won) {
            streak++
            multiplier = (kotlin.math.round((multiplier * stepOdds) * 100.0) / 100.0).coerceAtMost(12.5)
            statusText = "إصابة موفقة! السلسلة: $streak"
            if (multiplier >= 12.5) {
                cashout()
            }
        } else {
            isPlaying = false
            activeStake = 0.0
            statusText = "للأسف، الورقة كانت ${next.rankLabel}${next.suit}"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF2B0B3F), Color(0xFF561254), Color(0xFF1A0A28))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        GameTopBar(
            balance = balance,
            onBack = onBack,
            onAddFunds = onNavigateDeposit,
            title = "Royal Hi-Lo",
            darkTheme = true
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = Color.Black.copy(alpha = 0.35f),
                border = BorderStroke(1.dp, GoldAccent)
            ) {
                LtrNumberText(
                    text = "Multiplier: ${String.format("%.2f", multiplier)}x",
                    style = TextStyle(
                        fontFamily = OutfitFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    ),
                    color = GoldAccent,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Large Playing Card
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color.White,
                    shadowElevation = 12.dp,
                    modifier = Modifier.size(width = 168.dp, height = 236.dp)
                ) {
                    val suitColor = if (currentCard.isRed) Color(0xFFD32F2F) else Color(0xFF1E293B)
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "${currentCard.rankLabel}\n${currentCard.suit}",
                            style = TextStyle(
                                fontFamily = OutfitFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp,
                                lineHeight = 24.sp
                            ),
                            color = suitColor,
                            modifier = Modifier.align(Alignment.TopStart)
                        )
                        Text(
                            text = currentCard.suit,
                            fontSize = 68.sp,
                            color = suitColor,
                            modifier = Modifier.align(Alignment.Center)
                        )
                        Text(
                            text = "${currentCard.rankLabel}\n${currentCard.suit}",
                            style = TextStyle(
                                fontFamily = OutfitFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp,
                                lineHeight = 24.sp
                            ),
                            color = suitColor,
                            modifier = Modifier.align(Alignment.BottomEnd)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = statusText,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = { guess(true) },
                    enabled = isPlaying,
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldBright),
                    modifier = Modifier
                        .weight(1f)
                        .height(58.dp)
                ) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = null)
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("أعلى x$higherOdds", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { guess(false) },
                    enabled = isPlaying,
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonLoss),
                    modifier = Modifier
                        .weight(1f)
                        .height(58.dp)
                ) {
                    Icon(Icons.Default.ArrowDownward, contentDescription = null)
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("أقل x$lowerOdds", fontWeight = FontWeight.Bold)
                }
            }
        }

        val canCashout = isPlaying && streak > 0
        QuickStakeControlPanel(
            stakeText = stakeText,
            onStakeChange = { stakeText = it },
            balance = balance,
            enabled = !isPlaying,
            primaryButtonText = when {
                canCashout -> "TAKE ${formatEgp(activeStake * multiplier)}"
                isPlaying -> "توقّع الورقة"
                else -> "STAKE"
            },
            primaryButtonColor = if (canCashout) EmeraldBright else SkyActionBlue,
            onPrimaryClick = {
                if (canCashout) cashout() else if (!isPlaying) startRound()
            }
        )
    }
}
