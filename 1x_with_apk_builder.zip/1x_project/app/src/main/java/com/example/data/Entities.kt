package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val displayName: String,
    val username: String,
    val email: String,
    val password: String,
    val balance: Double,
    val isActiveSession: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

enum class TransactionType {
    DEPOSIT,
    WITHDRAW,
    BET,
    WIN,
    BONUS
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val type: TransactionType,
    val title: String,
    val methodOrGame: String,
    val amount: Double,
    val details: String,
    val status: String,
    val timestamp: Long = System.currentTimeMillis()
)
