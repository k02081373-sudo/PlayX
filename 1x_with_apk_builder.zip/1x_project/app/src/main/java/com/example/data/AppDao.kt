package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM users WHERE isActiveSession = 1 LIMIT 1")
    fun observeActiveUser(): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE isActiveSession = 1 LIMIT 1")
    suspend fun getActiveUserOnce(): UserEntity?

    @Query("SELECT * FROM users WHERE (LOWER(username) = LOWER(:identifier) OR LOWER(email) = LOWER(:identifier)) LIMIT 1")
    suspend fun findUserByIdentifier(identifier: String): UserEntity?

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun findUserByUsername(username: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET isActiveSession = 0")
    suspend fun clearAllSessions()

    @Query("UPDATE users SET isActiveSession = 1 WHERE id = :userId")
    suspend fun activateSession(userId: Int)

    @Query("UPDATE users SET balance = balance + :delta WHERE id = :userId")
    suspend fun adjustBalance(userId: Int, delta: Double)

    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY timestamp DESC")
    fun observeTransactions(userId: Int): Flow<List<TransactionEntity>>

    @Insert
    suspend fun insertTransaction(transaction: TransactionEntity)
}
