package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf

sealed class AuthResult {
    data object Success : AuthResult()
    data class Error(val message: String) : AuthResult()
}

sealed class WalletResult {
    data class Success(val message: String) : WalletResult()
    data class Error(val message: String) : WalletResult()
}

class SimulationRepository(private val dao: AppDao) {

    val activeUser: Flow<UserEntity?> = dao.observeActiveUser()

    @Suppress("OPT_IN_USAGE")
    val transactions: Flow<List<TransactionEntity>> = activeUser.flatMapLatest { user ->
        if (user == null) flowOf(emptyList()) else dao.observeTransactions(user.id)
    }

    suspend fun quickDemoLogin(): AuthResult {
        dao.clearAllSessions()
        val existing = dao.findUserByUsername("demo_player")
        if (existing != null) {
            dao.activateSession(existing.id)
            return AuthResult.Success
        }
        val demoId = dao.insertUser(
            UserEntity(
                displayName = "لاعب تجريبي",
                username = "demo_player",
                email = "demo@playx.sim",
                password = "demo",
                balance = 1000.0,
                isActiveSession = true
            )
        ).toInt()
        dao.insertTransaction(
            TransactionEntity(
                userId = demoId,
                type = TransactionType.BONUS,
                title = "مكافأة ترحيبية",
                methodOrGame = "حساب تجريبي",
                amount = 1000.0,
                details = "رصيد افتتاحي للمحاكاة والتسلية",
                status = "مكتمل (محاكاة)"
            )
        )
        return AuthResult.Success
    }

    suspend fun login(identifier: String, password: String): AuthResult {
        val cleanId = identifier.trim()
        if (cleanId.isEmpty() || password.isEmpty()) {
            return AuthResult.Error("يرجى إدخال اسم المستخدم وكلمة المرور")
        }
        val user = dao.findUserByIdentifier(cleanId)
            ?: return AuthResult.Error("لم يتم العثور على الحساب. جرّب إنشاء حساب جديد أو الدخول التجريبي")
        if (user.password != password) {
            return AuthResult.Error("كلمة المرور غير صحيحة")
        }
        dao.clearAllSessions()
        dao.activateSession(user.id)
        return AuthResult.Success
    }

    suspend fun register(displayName: String, username: String, email: String, password: String): AuthResult {
        val cleanName = displayName.trim().ifEmpty { username.trim() }
        val cleanUser = username.trim()
        val cleanEmail = email.trim().ifEmpty { "$cleanUser@playx.sim" }
        if (cleanUser.length < 3) {
            return AuthResult.Error("اسم المستخدم يجب أن يكون 3 أحرف على الأقل")
        }
        if (password.length < 4) {
            return AuthResult.Error("كلمة المرور يجب أن تكون 4 أحرف على الأقل")
        }
        if (dao.findUserByUsername(cleanUser) != null) {
            return AuthResult.Error("اسم المستخدم مستخدم بالفعل")
        }
        dao.clearAllSessions()
        val newId = dao.insertUser(
            UserEntity(
                displayName = cleanName,
                username = cleanUser,
                email = cleanEmail,
                password = password,
                balance = 1000.0,
                isActiveSession = true
            )
        ).toInt()
        dao.insertTransaction(
            TransactionEntity(
                userId = newId,
                type = TransactionType.BONUS,
                title = "مكافأة حساب جديد",
                methodOrGame = "النظام الترفيهي",
                amount = 1000.0,
                details = "رصيد تجريبي مجاني للبدء",
                status = "مكتمل (محاكاة)"
            )
        )
        return AuthResult.Success
    }

    suspend fun logout() {
        dao.clearAllSessions()
    }

    suspend fun simulateDeposit(method: String, amount: Double): WalletResult {
        val user = dao.getActiveUserOnce() ?: return WalletResult.Error("يجب تسجيل الدخول أولاً")
        if (amount < 50.0) {
            return WalletResult.Error("الحد الأدنى للإيداع هو 50 ج.م")
        }
        if (amount > 50000.0) {
            return WalletResult.Error("الحد الأقصى للإيداع في المرة الواحدة 50,000 ج.م")
        }
        dao.adjustBalance(user.id, amount)
        dao.insertTransaction(
            TransactionEntity(
                userId = user.id,
                type = TransactionType.DEPOSIT,
                title = "إيداع رصيد",
                methodOrGame = "$method (محاكاة)",
                amount = amount,
                details = "شحن فوري للرصيد الافتراضي",
                status = "مكتمل (محاكاة)"
            )
        )
        return WalletResult.Success("تمت إضافة ${String.format("%.2f", amount)} ج.م إلى رصيدك")
    }

    suspend fun simulateWithdraw(amount: Double, walletPhone: String): WalletResult {
        val user = dao.getActiveUserOnce() ?: return WalletResult.Error("يجب تسجيل الدخول أولاً")
        if (amount < 50.0) {
            return WalletResult.Error("الحد الأدنى للسحب التجريبي هو 50 ج.م")
        }
        if (walletPhone.trim().length < 8) {
            return WalletResult.Error("يرجى إدخال رقم محفظة تجريبي صحيح")
        }
        if (user.balance < amount) {
            return WalletResult.Error("الرصيد المتاح غير كافٍ")
        }
        dao.adjustBalance(user.id, -amount)
        dao.insertTransaction(
            TransactionEntity(
                userId = user.id,
                type = TransactionType.WITHDRAW,
                title = "طلب سحب",
                methodOrGame = "محفظة إلكترونية (محاكاة)",
                amount = -amount,
                details = "إلى الرقم التجريبي: ${walletPhone.trim()}",
                status = "قيد المراجعة (محاكاة)"
            )
        )
        return WalletResult.Success("تم تسجيل طلب السحب بمبلغ ${String.format("%.2f", amount)} ج.م")
    }

    suspend fun claimFreeRefill(): WalletResult {
        val user = dao.getActiveUserOnce() ?: return WalletResult.Error("يجب تسجيل الدخول أولاً")
        val refillAmount = 500.0
        dao.adjustBalance(user.id, refillAmount)
        dao.insertTransaction(
            TransactionEntity(
                userId = user.id,
                type = TransactionType.BONUS,
                title = "شحن مجاني للمحاكاة",
                methodOrGame = "مكافأة مجانية",
                amount = refillAmount,
                details = "إعادة تعبئة رصيد اللعب",
                status = "مكتمل (محاكاة)"
            )
        )
        return WalletResult.Success("تمت إضافة 500.00 ج.م رصيد مجاني!")
    }

    suspend fun placeBet(gameName: String, stake: Double): Boolean {
        val user = dao.getActiveUserOnce() ?: return false
        if (stake <= 0.0 || user.balance < stake) return false
        dao.adjustBalance(user.id, -stake)
        dao.insertTransaction(
            TransactionEntity(
                userId = user.id,
                type = TransactionType.BET,
                title = "جولة لعب - $gameName",
                methodOrGame = gameName,
                amount = -stake,
                details = "قيمة الرهان",
                status = "محاكاة"
            )
        )
        return true
    }

    suspend fun creditWin(gameName: String, payout: Double, multiplier: Double) {
        val user = dao.getActiveUserOnce() ?: return
        if (payout <= 0.0) return
        dao.adjustBalance(user.id, payout)
        dao.insertTransaction(
            TransactionEntity(
                userId = user.id,
                type = TransactionType.WIN,
                title = "ربح جولة - $gameName",
                methodOrGame = gameName,
                amount = payout,
                details = "مضاعف x${String.format("%.2f", multiplier)}",
                status = "ربح (محاكاة)"
            )
        )
    }
}
