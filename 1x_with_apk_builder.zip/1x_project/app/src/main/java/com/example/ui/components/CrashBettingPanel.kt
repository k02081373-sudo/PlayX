package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CrashArenaBg
import com.example.ui.theme.CrashCardBg
import com.example.ui.theme.CrashOrange
import com.example.ui.theme.CrimsonLoss
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.SkyActionBlue
import com.example.ui.viewmodel.CrashGamePhase
import com.example.ui.viewmodel.CrashUiState

@Composable
fun CrashBettingPanel(
    uiState: CrashUiState,
    onStakeChange: (String) -> Unit,
    onSelectQuickStake: (Int) -> Unit,
    onMinStake: () -> Unit,
    onHalveStake: () -> Unit,
    onDoubleStake: () -> Unit,
    onMaxStake: () -> Unit,
    onStartRound: () -> Unit,
    onCashOut: () -> Unit,
    onNavigateDeposit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isFlying = uiState.phase == CrashGamePhase.FLYING
    val hasError = !isFlying && uiState.stakeError != null

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("crash_betting_panel"),
        shape = RoundedCornerShape(18.dp),
        color = CrashCardBg,
        border = BorderStroke(
            width = 1.dp,
            color = when {
                isFlying -> EmeraldBright.copy(alpha = 0.45f)
                hasError -> CrimsonLoss.copy(alpha = 0.7f)
                else -> Color.White.copy(alpha = 0.08f)
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header row: Betting panel title + Available virtual balance
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "لوحة الرهان (رصيد اللعب)",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFFCBD5E1)
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "المتاح:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF94A3B8)
                    )
                    LtrNumberText(
                        text = "${formatEgp(uiState.balance)} ج.م",
                        style = TextStyle(
                            fontFamily = OutfitFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        ),
                        color = if (uiState.balance >= 1.0) EmeraldBright else CrimsonLoss
                    )
                }
            }

            // Quick multiplier / preset chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                BetModifierChip("MIN", enabled = !isFlying, onClick = onMinStake, modifier = Modifier.weight(1f))
                BetModifierChip("X/2", enabled = !isFlying, onClick = onHalveStake, modifier = Modifier.weight(1f))
                BetModifierChip("X2", enabled = !isFlying, onClick = onDoubleStake, modifier = Modifier.weight(1f))
                BetModifierChip("MAX", enabled = !isFlying, onClick = onMaxStake, modifier = Modifier.weight(1f))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(10, 20, 50, 100).forEach { preset ->
                    val selected = uiState.stakeInput == preset.toString()
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(32.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable(enabled = !isFlying) { onSelectQuickStake(preset) }
                            .testTag("crash_preset_$preset"),
                        shape = RoundedCornerShape(10.dp),
                        color = if (selected) CrashOrange.copy(alpha = 0.25f) else CrashArenaBg,
                        border = BorderStroke(
                            1.dp,
                            if (selected) CrashOrange else Color.White.copy(alpha = 0.08f)
                        )
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            LtrNumberText(
                                text = "$preset ج.م",
                                style = TextStyle(
                                    fontFamily = OutfitFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                ),
                                color = if (isFlying) Color(0xFF64748B) else Color.White
                            )
                        }
                    }
                }
            }

            // Stake Input + Primary Action Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .weight(0.95f)
                        .height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = CrashArenaBg,
                    border = BorderStroke(
                        width = 1.5.dp,
                        color = when {
                            isFlying -> Color.White.copy(alpha = 0.1f)
                            hasError -> CrimsonLoss
                            else -> SkyActionBlue.copy(alpha = 0.45f)
                        }
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "ج.م",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color(0xFF94A3B8)
                        )
                        BasicTextField(
                            value = uiState.stakeInput,
                            onValueChange = onStakeChange,
                            enabled = !isFlying,
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            cursorBrush = SolidColor(CrashOrange),
                            textStyle = TextStyle(
                                fontFamily = OutfitFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = if (isFlying) Color(0xFF94A3B8) else Color.White,
                                textAlign = TextAlign.Center
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("crash_stake_input")
                        )
                    }
                }

                val potentialWin = uiState.activeStake * uiState.multiplier
                Button(
                    onClick = {
                        if (isFlying) onCashOut() else onStartRound()
                    },
                    enabled = isFlying || uiState.isStakeValid,
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isFlying) EmeraldBright else CrashOrange,
                        disabledContainerColor = Color(0xFF334155),
                        disabledContentColor = Color(0xFF94A3B8)
                    ),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    modifier = Modifier
                        .weight(1.3f)
                        .height(52.dp)
                        .testTag("crash_action_button")
                ) {
                    Text(
                        text = if (isFlying) {
                            "Cash Out (${formatEgp(potentialWin)})"
                        } else {
                            "بدء المحاكاة"
                        },
                        style = TextStyle(
                            fontFamily = OutfitFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp
                        ),
                        color = if (isFlying || uiState.isStakeValid) Color.White else Color(0xFF94A3B8)
                    )
                }
            }

            // Live Validation Error Banner with quick Top-Up shortcut
            AnimatedVisibility(visible = hasError) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CrimsonLoss.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, CrimsonLoss.copy(alpha = 0.45f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("crash_stake_error_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ErrorOutline,
                                contentDescription = null,
                                tint = Color(0xFFFF8A80),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = uiState.stakeError.orEmpty(),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFFFCDD2)
                            )
                        }
                        if ((uiState.stakeInput.toDoubleOrNull() ?: 0.0) > uiState.balance) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = EmeraldBright.copy(alpha = 0.2f),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable(onClick = onNavigateDeposit)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AddCircle,
                                        contentDescription = "شحن",
                                        tint = EmeraldBright,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "شحن",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = EmeraldBright,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BetModifierChip(
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .height(30.dp)
            .clip(RoundedCornerShape(8.dp))
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        color = SkyActionBlue.copy(alpha = if (enabled) 0.16f else 0.06f),
        border = BorderStroke(
            1.dp,
            SkyActionBlue.copy(alpha = if (enabled) 0.4f else 0.15f)
        )
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = TextStyle(
                    fontFamily = OutfitFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                ),
                color = if (enabled) Color.White else Color(0xFF64748B)
            )
        }
    }
}
