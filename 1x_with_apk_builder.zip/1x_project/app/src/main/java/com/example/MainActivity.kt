package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DepositScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.WithdrawScreen
import com.example.ui.screens.games.AppleOfFortuneScreen
import com.example.ui.screens.games.CrashGameScreen
import com.example.ui.screens.games.FourAcesScreen
import com.example.ui.screens.games.GemsOdysseyScreen
import com.example.ui.screens.games.MundialScreen
import com.example.ui.screens.games.RoyalHiLoScreen
import com.example.ui.theme.PlayXTheme
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.SessionState

object Routes {
    const val HOME = "home"
    const val DEPOSIT = "deposit"
    const val WITHDRAW = "withdraw"
    const val HISTORY = "history"
    const val GAME_CRASH = "game_crash"
    const val GAME_APPLE = "game_apple"
    const val GAME_GEMS = "game_gems"
    const val GAME_HILO = "game_hilo"
    const val GAME_MUNDIAL = "game_mundial"
    const val GAME_ACES = "game_aces"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                PlayXTheme {
                    PlayXRoot()
                }
            }
        }
    }
}

@Composable
fun PlayXRoot(viewModel: MainViewModel = viewModel()) {
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val authError by viewModel.authError.collectAsStateWithLifecycle()
    val walletFeedback by viewModel.walletFeedback.collectAsStateWithLifecycle()

    when (val state = sessionState) {
        SessionState.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        SessionState.Unauthenticated -> {
            AuthScreen(
                errorMessage = authError,
                onLogin = viewModel::login,
                onRegister = viewModel::register,
                onQuickDemoLogin = viewModel::quickDemoLogin,
                onClearError = viewModel::clearAuthError
            )
        }
        is SessionState.Authenticated -> {
            val user = state.user
            val navController = rememberNavController()

            NavHost(
                navController = navController,
                startDestination = Routes.HOME
            ) {
                composable(Routes.HOME) {
                    HomeScreen(
                        user = user,
                        onNavigateDeposit = { navController.navigate(Routes.DEPOSIT) },
                        onNavigateWithdraw = { navController.navigate(Routes.WITHDRAW) },
                        onNavigateHistory = { navController.navigate(Routes.HISTORY) },
                        onOpenGame = { route -> navController.navigate(route) },
                        onClaimFreeRefill = viewModel::claimFreeRefill,
                        onLogout = viewModel::logout
                    )
                }

                composable(Routes.DEPOSIT) {
                    DepositScreen(
                        walletFeedback = walletFeedback,
                        onConfirmDeposit = viewModel::simulateDeposit,
                        onClearFeedback = viewModel::clearWalletFeedback,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Routes.WITHDRAW) {
                    WithdrawScreen(
                        balance = user.balance,
                        walletFeedback = walletFeedback,
                        onConfirmWithdraw = viewModel::simulateWithdraw,
                        onClearFeedback = viewModel::clearWalletFeedback,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Routes.HISTORY) {
                    HistoryScreen(
                        transactions = transactions,
                        onClaimRefill = viewModel::claimFreeRefill,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Routes.GAME_CRASH) {
                    CrashGameScreen(
                        onNavigateDeposit = { navController.navigate(Routes.DEPOSIT) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Routes.GAME_APPLE) {
                    AppleOfFortuneScreen(
                        balance = user.balance,
                        onPlaceBet = viewModel::placeBet,
                        onCreditWin = viewModel::creditWin,
                        onNavigateDeposit = { navController.navigate(Routes.DEPOSIT) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Routes.GAME_GEMS) {
                    GemsOdysseyScreen(
                        balance = user.balance,
                        onPlaceBet = viewModel::placeBet,
                        onCreditWin = viewModel::creditWin,
                        onNavigateDeposit = { navController.navigate(Routes.DEPOSIT) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Routes.GAME_HILO) {
                    RoyalHiLoScreen(
                        balance = user.balance,
                        onPlaceBet = viewModel::placeBet,
                        onCreditWin = viewModel::creditWin,
                        onNavigateDeposit = { navController.navigate(Routes.DEPOSIT) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Routes.GAME_MUNDIAL) {
                    MundialScreen(
                        balance = user.balance,
                        onPlaceBet = viewModel::placeBet,
                        onCreditWin = viewModel::creditWin,
                        onNavigateDeposit = { navController.navigate(Routes.DEPOSIT) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(Routes.GAME_ACES) {
                    FourAcesScreen(
                        balance = user.balance,
                        onPlaceBet = viewModel::placeBet,
                        onCreditWin = viewModel::creditWin,
                        onNavigateDeposit = { navController.navigate(Routes.DEPOSIT) },
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
