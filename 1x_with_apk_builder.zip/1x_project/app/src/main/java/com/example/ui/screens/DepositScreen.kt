package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.WalletResult
import com.example.ui.components.LtrNumberText
import com.example.ui.components.SimulationNoticePill
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.LobbyBackground
import com.example.ui.theme.NavyBrand
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.TextDarkPrimary
import com.example.ui.theme.TextDarkSecondary
import kotlinx.coroutines.launch

private data class DepositMethodOption(
    val name: String,
    val demoNumber: String,
    val accentColor: Color
)

private val DepositMethods = listOf(
    DepositMethodOption("فودافون كاش", "01018538934", Color(0xFFE60000)),
    DepositMethodOption("اتصالات كاش", "01018538934", Color(0xFF66B132)),
    DepositMethodOption("أورانج كاش", "01018538934", Color(0xFFFF7900))
)

@Composable
fun DepositScreen(
    walletFeedback: WalletResult?,
    onConfirmDeposit: (String, String) -> Unit,
    onClearFeedback: () -> Unit,
    onBack: () -> Unit
) {
    var selectedMethod by remember { mutableStateOf(DepositMethods.first()) }
    var amountText by remember { mutableStateOf("200") }
    val snackbarHostState = remember { SnackbarHostState() }
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(walletFeedback) {
        if (walletFeedback != null) {
            val msg = when (walletFeedback) {
                is WalletResult.Success -> walletFeedback.message
                is WalletResult.Error -> walletFeedback.message
            }
            snackbarHostState.showSnackbar(msg)
            onClearFeedback()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = LobbyBackground,
        topBar = {
            Surface(color = Color.White, shadowElevation = 2.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("deposit_back_button")
                    ) {
                        Text(
                            text = "رجوع",
                            style = MaterialTheme.typography.titleMedium,
                            color = NavyBrand
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "رجوع",
                            tint = NavyBrand
                        )
                    }
                    Text(
                        text = "إيداع أموال",
                        style = MaterialTheme.typography.titleLarge,
                        color = NavyBrand
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SimulationNoticePill(modifier = Modifier.align(Alignment.CenterHorizontally))

            Text(
                text = "اختر وسيلة الإيداع:",
                style = MaterialTheme.typography.titleMedium,
                color = NavyBrand
            )

            // Methods Card matching Screenshot 4
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    DepositMethods.forEachIndexed { index, method ->
                        val isSelected = selectedMethod == method
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isSelected) Color(0xFFF0F6FF) else Color.Transparent
                                )
                                .clickable { selectedMethod = method }
                                .padding(horizontal = 18.dp, vertical = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = method.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) NavyBrand else TextDarkPrimary
                            )
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedMethod = method }
                            )
                        }
                        if (index < DepositMethods.lastIndex) {
                            HorizontalDivider(color = Color(0xFFEDF1F7))
                        }
                    }
                }
            }

            // Detail & Amount Card matching Screenshot 4
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color.White,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = selectedMethod.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = NavyBrand
                    )

                    Text(
                        text = "رقم التحويل (محاكاة فقط - لا تحوّل أموالاً حقيقية):",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextDarkSecondary
                    )

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFF3F6FA),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            LtrNumberText(
                                text = selectedMethod.demoNumber,
                                style = TextStyle(
                                    fontFamily = OutfitFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                ),
                                color = NavyBrand
                            )
                            Button(
                                onClick = {
                                    clipboard.setText(AnnotatedString(selectedMethod.demoNumber))
                                    scope.launch {
                                        snackbarHostState.showSnackbar("تم نسخ الرقم: ${selectedMethod.demoNumber}")
                                    }
                                },
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = NavyBrand)
                            ) {
                                Text("نسخ", color = Color.White)
                            }
                        }
                    }

                    Text(
                        text = "أقل مبلغ للإيداع 50 ج.م:",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = TextDarkPrimary
                    )

                    // Quick Preset Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("100", "200", "500", "1000").forEach { preset ->
                            val isSelected = amountText == preset
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .clickable { amountText = preset },
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) NavyBrand else Color(0xFFF3F6FA),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) NavyBrand else Color(0xFFD5DEE9)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    LtrNumberText(
                                        text = preset,
                                        style = TextStyle(
                                            fontFamily = OutfitFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        ),
                                        color = if (isSelected) Color.White else NavyBrand
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { input ->
                            if (input.all { it.isDigit() || it == '.' }) {
                                amountText = input
                            }
                        },
                        placeholder = {
                            Text(
                                "أدخل المبلغ",
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("deposit_amount_input")
                    )
                }
            }

            Button(
                onClick = { onConfirmDeposit(selectedMethod.name, amountText) },
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF287D3C)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("deposit_confirm_button")
            ) {
                Text(
                    text = "تأكيد الإيداع",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
