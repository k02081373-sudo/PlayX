package com.example.ui.screens.games

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GameTopBar
import com.example.ui.components.LtrNumberText
import com.example.ui.components.QuickStakeControlPanel
import com.example.ui.components.formatEgp
import com.example.ui.theme.CrimsonLoss
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.SkyActionBlue
import kotlinx.coroutines.launch
import kotlin.random.Random

@Composable
fun FourAcesScreen(
    balance: Double,
    onPlaceBet: suspend (String, Double) -> Boolean,
    onCreditWin: (String, Double, Double) -> Unit,
    onNavigateDeposit: () -> Unit,
    onBack: () -> Unit
) {
    var stakeText by remember { mutableStateOf("20") }
    var isPlaying by remember { mutableStateOf(false) }
    var activeStake by remember { mutableDoubleStateOf(0.0) }
    var aceIndex by remember { mutableIntStateOf(0) }
    var pickedIndex by remember { mutableIntStateOf(-1) }
    var statusText by remember { mutableStateOf("اضغط STAKE واختر البطاقة التي تخفي الآس (A♠)") }
    val scope = rememberCoroutineScope()

    fun startRound() {
        val stake = stakeText.toDoubleOrNull() ?: 0.0
        if (stake <= 0.0 || stake > balance) {
            statusText = "الرصيد غير كافٍ"
            return
        }
        scope.launch {
            if (onPlaceBet("Four Aces", stake)) {
                aceIndex = Random.nextInt(4)
                pickedIndex = -1
                activeStake = stake
                isPlaying = true
                statusText = "اختر ورقة واحدة من الأربعة!"
            }
        }
    }

    fun pickCard(idx: Int) {
        if (!isPlaying) return
        pickedIndex = idx
        isPlaying = false
        if (idx == aceIndex) {
            val mult = 3.94
            val payout = activeStake * mult
            onCreditWin("Four Aces", payout, mult)
            statusText = "أحسنت! عثرت على الآس وربحت +${formatEgp(payout)} ج.م"
        } else {
            statusText = "ليست الآس! كانت في البطاقة رقم ${aceIndex + 1}"
        }
        activeStake = 0.0
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF231123), Color(0xFF53182A), Color(0xFF1A1D33))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        GameTopBar(
            balance = balance,
            onBack = onBack,
            onAddFunds = onNavigateDeposit,
            title = "Four Aces",
            darkTheme = true
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                shape = RoundedCornerShape(50),
                color = GoldAccent.copy(alpha = 0.16f),
                border = BorderStroke(1.dp, GoldAccent)
            ) {
                LtrNumberText(
                    text = "WIN X3.94",
                    style = TextStyle(
                        fontFamily = OutfitFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp
                    ),
                    color = GoldAccent,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 7.dp)
                )
            }

            Spacer(modifier = Modifier.height(26.dp))

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val decoys = listOf("7♦", "9♣", "J♥", "8♦")
                    for (i in 0..3) {
                        val revealed = pickedIndex != -1
                        val isAce = i == aceIndex
                        val isUserPick = i == pickedIndex

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .height(145.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .clickable(enabled = isPlaying) { pickCard(i) },
                            shape = RoundedCornerShape(16.dp),
                            color = when {
                                !revealed -> Color(0xFF28344B)
                                isAce -> Color(0xFFFFFDE7)
                                else -> Color.White
                            },
                            border = BorderStroke(
                                width = if (isUserPick) 3.dp else 1.5.dp,
                                color = when {
                                    !revealed && isPlaying -> GoldAccent
                                    isUserPick && isAce -> EmeraldBright
                                    isUserPick && !isAce -> CrimsonLoss
                                    else -> Color.White.copy(alpha = 0.25f)
                                }
                            )
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (!revealed) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = "ورقة مقلوبة",
                                        tint = GoldAccent.copy(alpha = 0.7f),
                                        modifier = Modifier.size(34.dp)
                                    )
                                } else {
                                    Text(
                                        text = if (isAce) "A♠" else decoys[i],
                                        style = TextStyle(
                                            fontFamily = OutfitFontFamily,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 30.sp
                                        ),
                                        color = if (isAce) Color(0xFF1E293B) else Color(0xFFD32F2F)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Text(
                text = statusText,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
        }

        QuickStakeControlPanel(
            stakeText = stakeText,
            onStakeChange = { stakeText = it },
            balance = balance,
            enabled = !isPlaying,
            primaryButtonText = if (isPlaying) "اختر ورقة" else "STAKE",
            primaryButtonColor = SkyActionBlue,
            onPrimaryClick = { if (!isPlaying) startRound() }
        )
    }
}
