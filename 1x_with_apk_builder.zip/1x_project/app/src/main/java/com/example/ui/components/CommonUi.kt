package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.SkyActionBlue
import java.util.Locale

fun formatEgp(amount: Double): String {
    return String.format(Locale.US, "%.2f", amount)
}

@Composable
fun LtrNumberText(
    text: String,
    style: TextStyle = MaterialTheme.typography.bodyLarge,
    color: Color = Color.Unspecified,
    modifier: Modifier = Modifier
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Text(
            text = text,
            style = style,
            color = color,
            modifier = modifier
        )
    }
}

@Composable
fun SimulationNoticePill(
    modifier: Modifier = Modifier,
    darkMode: Boolean = false
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = if (darkMode) Color.White.copy(alpha = 0.1f) else Color(0xFFE3F2FD),
        border = BorderStroke(
            1.dp,
            if (darkMode) Color.White.copy(alpha = 0.2f) else SkyActionBlue.copy(alpha = 0.35f)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.SportsEsports,
                contentDescription = "محاكاة ترفيهية",
                tint = if (darkMode) Color(0xFFFFD54F) else SkyActionBlue,
                modifier = Modifier.size(15.dp)
            )
            Text(
                text = "محاكاة",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = if (darkMode) Color(0xFFE2E8F0) else Color(0xFF0D47A1)
            )
        }
    }
}

@Composable
fun GameTopBar(
    balance: Double,
    onBack: () -> Unit,
    onAddFunds: (() -> Unit)? = null,
    title: String? = null,
    darkTheme: Boolean = true
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .size(48.dp)
                .testTag("game_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "رجوع",
                tint = if (darkTheme) Color.White else Color(0xFF182230)
            )
        }

        Surface(
            shape = RoundedCornerShape(50),
            color = if (darkTheme) Color(0xFF232C3D) else Color(0xFF283442),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .let { mod -> if (onAddFunds != null) mod.clickable(onClick = onAddFunds) else mod }
                .testTag("game_balance_pill")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (onAddFunds != null) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(EmeraldBright.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "إضافة رصيد",
                            tint = EmeraldBright,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                LtrNumberText(
                    text = "${formatEgp(balance)} ج.م",
                    style = TextStyle(
                        fontFamily = OutfitFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    ),
                    color = Color.White
                )
            }
        }

        if (title != null) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = if (darkTheme) Color.White else Color(0xFF182230),
                fontWeight = FontWeight.Bold
            )
        } else {
            Spacer(modifier = Modifier.width(48.dp))
        }
    }
}

@Composable
fun QuickStakeControlPanel(
    stakeText: String,
    onStakeChange: (String) -> Unit,
    balance: Double,
    enabled: Boolean,
    primaryButtonText: String,
    primaryButtonColor: Color,
    onPrimaryClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF131B29).copy(alpha = 0.94f))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val currentVal = stakeText.toDoubleOrNull() ?: 20.0
            QuickChipButton("MIN", enabled, Color(0xFF2196F3), Modifier.weight(1f)) {
                onStakeChange("10")
            }
            QuickChipButton("X2", enabled, Color(0xFF283244), Modifier.weight(1f)) {
                val next = (currentVal * 2.0).coerceAtMost(balance.coerceAtLeast(10.0))
                onStakeChange(formatEgp(next).removeSuffix(".00"))
            }
            QuickChipButton("X/2", enabled, Color(0xFF2196F3), Modifier.weight(1f)) {
                val next = (currentVal / 2.0).coerceAtLeast(10.0)
                onStakeChange(formatEgp(next).removeSuffix(".00"))
            }
            QuickChipButton("MAX", enabled, Color(0xFF283244), Modifier.weight(1f)) {
                val next = balance.coerceAtLeast(10.0).coerceAtMost(5000.0)
                onStakeChange(formatEgp(next).removeSuffix(".00"))
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF1E2736),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "ج.م",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF94A3B8)
                    )
                    BasicTextField(
                        value = stakeText,
                        onValueChange = { input ->
                            if (enabled && input.all { it.isDigit() || it == '.' } && input.length <= 7) {
                                onStakeChange(input)
                            }
                        },
                        enabled = enabled,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        cursorBrush = SolidColor(SkyActionBlue),
                        textStyle = TextStyle(
                            fontFamily = OutfitFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White,
                            textAlign = TextAlign.End
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("stake_input")
                    )
                }
            }

            Button(
                onClick = onPrimaryClick,
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = primaryButtonColor),
                contentPadding = PaddingValues(horizontal = 22.dp),
                modifier = Modifier
                    .height(50.dp)
                    .testTag("stake_primary_button")
            ) {
                Text(
                    text = primaryButtonText,
                    style = TextStyle(
                        fontFamily = OutfitFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    ),
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun QuickChipButton(
    label: String,
    enabled: Boolean,
    bgColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .height(38.dp)
            .clip(RoundedCornerShape(19.dp))
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(19.dp),
        color = if (enabled) bgColor else bgColor.copy(alpha = 0.45f)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = TextStyle(
                    fontFamily = OutfitFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                ),
                color = Color.White
            )
        }
    }
}
