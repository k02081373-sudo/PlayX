package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Brand & Lobby Colors (matching clean light lobby + vibrant accents)
val LobbyBackground = Color(0xFFF3F6FA)
val LobbySurface = Color(0xFFFFFFFF)
val SlateBalanceBg = Color(0xFF283442)
val SlateBalanceSecondary = Color(0xFF1E2833)

val SkyActionBlue = Color(0xFF1D9BF0)
val DeepRoyalBlue = Color(0xFF1466E0)
val NavyBrand = Color(0xFF0E2344)

// Financial / Action Accents
val EmeraldSuccess = Color(0xFF38A143)
val EmeraldBright = Color(0xFF4CAF50)
val WithdrawPurple = Color(0xFF5E47A6)
val CrashOrange = Color(0xFFFF6D00)
val GoldAccent = Color(0xFFFFD54F)
val CrimsonLoss = Color(0xFFE53935)

// Dark Game Arena Surfaces
val CrashArenaBg = Color(0xFF141A26)
val CrashCardBg = Color(0xFF1F2736)
val CrashPlotBg = Color(0xFF232C3D)

val ForestDarkBg = Color(0xFF0B2E1E)
val ForestMidBg = Color(0xFF144B30)
val WoodTileBase = Color(0xFF8C4A22)
val WoodTileRim = Color(0xFF542810)

val TextDarkPrimary = Color(0xFF182230)
val TextDarkSecondary = Color(0xFF607084)
val TextLightPrimary = Color(0xFFF8FAFC)
val TextLightSecondary = Color(0xFFA0B0C4)
