package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.UserEntity
import com.example.ui.components.AppleFortuneBannerArt
import com.example.ui.components.CrashBannerArt
import com.example.ui.components.FourAcesBannerArt
import com.example.ui.components.GemsOdysseyBannerArt
import com.example.ui.components.LtrNumberText
import com.example.ui.components.MundialBannerArt
import com.example.ui.components.RoyalHiLoBannerArt
import com.example.ui.components.SimulationNoticePill
import com.example.ui.components.formatEgp
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NavyBrand
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.SkyActionBlue
import com.example.ui.theme.TextDarkPrimary
import com.example.ui.theme.TextDarkSecondary

data class SimulatedGameInfo(
    val route: String,
    val title: String,
    val maxMultiplier: String,
    val arabicDescription: String
)

private val GridGames = listOf(
    SimulatedGameInfo(
        route = "game_gems",
        title = "Gems Odyssey",
        maxMultiplier = "win up to X10",
        arabicDescription = "شبكة ألماس 5×5: افتح الجواهر الخضراء لمضاعفة رصيدك وتجنب الفخاخ الخفية. يمكنك سحب أرباحك في أي خطوة!"
    ),
    SimulatedGameInfo(
        route = "game_hilo",
        title = "Royal Hi-Lo",
        maxMultiplier = "win up to X12.5",
        arabicDescription = "تحدي البطاقات الملكية: توقّع هل الورقة القادمة أعلى أم أقل من الورقة الظاهرة وواصل السلسلة لرفع المضاعف."
    ),
    SimulatedGameInfo(
        route = "game_mundial",
        title = "Mundial",
        maxMultiplier = "win up to X57",
        arabicDescription = "ركلات الترجيح العالمية: اختر زاوية التسديد لتجاوز حارس المرمى ومضاعفة مكاسبك مع كل هدف."
    ),
    SimulatedGameInfo(
        route = "game_aces",
        title = "Four Aces",
        maxMultiplier = "win up to X3.94",
        arabicDescription = "أربعة أوراق مقلوبة: اعثر على ورقة الآس (Ace) المخفية لتربح x3.94 من قيمة رهانك فوراً."
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    user: UserEntity,
    onNavigateDeposit: () -> Unit,
    onNavigateWithdraw: () -> Unit,
    onNavigateHistory: () -> Unit,
    onOpenGame: (String) -> Unit,
    onClaimFreeRefill: () -> Unit,
    onLogout: () -> Unit
) {
    var selectedInfoGame by remember { mutableStateOf<SimulatedGameInfo?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF6F7FB))
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Header matching Screenshot 1 (Balance dark card + stacked Withdraw/Deposit blue pills)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Balance Card
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .height(88.dp),
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF2B343E),
                shadowElevation = 2.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.Start
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الرصيد الحالي",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFA7B4C2)
                        )
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = GoldAccent.copy(alpha = 0.16f)
                        ) {
                            Text(
                                text = "محاكاة",
                                style = MaterialTheme.typography.labelSmall,
                                color = GoldAccent,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        LtrNumberText(
                            text = formatEgp(user.balance),
                            style = TextStyle(
                                fontFamily = OutfitFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 24.sp
                            ),
                            color = Color.White
                        )
                        Text(
                            text = "جنيه",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                }
            }

            // Stacked Withdraw / Deposit Blue Pill Buttons matching Screenshot 1
            Column(
                modifier = Modifier.width(96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onNavigateWithdraw,
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A8EEA)),
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .testTag("home_withdraw_button")
                ) {
                    Text(
                        text = "سحب",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = onNavigateDeposit,
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A8EEA)),
                    contentPadding = PaddingValues(0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .testTag("home_deposit_button")
                ) {
                    Text(
                        text = "إيداع",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Compact Utility Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            SimulationNoticePill()

            Row(
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (user.balance < 100.0) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = EmeraldSuccess.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable(onClick = onClaimFreeRefill)
                            .testTag("home_refill_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CardGiftcard,
                                contentDescription = "شحن مجاني",
                                tint = EmeraldSuccess,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "+500 مجاني",
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldSuccess,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onNavigateHistory,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("home_history_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "سجل العمليات",
                        tint = NavyBrand,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = onLogout,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("home_logout_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Logout,
                        contentDescription = "تسجيل الخروج",
                        tint = TextDarkSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Featured Game 1: CRASH (matching Screenshot 1)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(176.dp)
                .clip(RoundedCornerShape(18.dp))
                .clickable { onOpenGame("game_crash") }
                .testTag("game_card_crash"),
            shape = RoundedCornerShape(18.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                CrashBannerArt()
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.4f))
                            )
                        )
                )
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Text(
                            text = "CRASH",
                            style = TextStyle(
                                fontFamily = OutfitFontFamily,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 44.sp,
                                letterSpacing = 2.sp
                            ),
                            color = Color(0xFFFFD54F),
                            modifier = Modifier.align(Alignment.Center)
                        )
                        Text(
                            text = "Crash",
                            style = TextStyle(
                                fontFamily = OutfitFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 24.sp
                            ),
                            color = Color.White,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }

        // Featured Game 2: Apple Of Fortune (matching Screenshot 1)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(176.dp)
                .clip(RoundedCornerShape(18.dp))
                .clickable { onOpenGame("game_apple") }
                .testTag("game_card_apple"),
            shape = RoundedCornerShape(18.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                AppleFortuneBannerArt()
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.48f))
                            )
                        )
                )
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Text(
                        text = "Apple Of Fortune",
                        style = TextStyle(
                            fontFamily = OutfitFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp
                        ),
                        color = Color.White,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
            }
        }

        // 2-Column Grid of Games matching Screenshot 1
        for (rowIdx in GridGames.indices step 2) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val first = GridGames[rowIdx]
                GridGameCard(
                    game = first,
                    modifier = Modifier.weight(1f),
                    onClick = { onOpenGame(first.route) },
                    onInfoClick = { selectedInfoGame = first }
                ) {
                    when (first.route) {
                        "game_gems" -> GemsOdysseyBannerArt()
                        "game_mundial" -> MundialBannerArt()
                        else -> RoyalHiLoBannerArt()
                    }
                }

                if (rowIdx + 1 < GridGames.size) {
                    val second = GridGames[rowIdx + 1]
                    GridGameCard(
                        game = second,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenGame(second.route) },
                        onInfoClick = { selectedInfoGame = second }
                    ) {
                        when (second.route) {
                            "game_hilo" -> RoyalHiLoBannerArt()
                            "game_aces" -> FourAcesBannerArt()
                            else -> GemsOdysseyBannerArt()
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
    }

    selectedInfoGame?.let { info ->
        ModalBottomSheet(onDismissRequest = { selectedInfoGame = null }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = info.title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = NavyBrand
                )
                SimulationNoticePill()
                Text(
                    text = info.arabicDescription,
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextDarkPrimary
                )
                Button(
                    onClick = {
                        val r = info.route
                        selectedInfoGame = null
                        onOpenGame(r)
                    },
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("العب الآن (محاكاة)", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun GridGameCard(
    game: SimulatedGameInfo,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onInfoClick: () -> Unit,
    artwork: @Composable () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag("card_${game.route}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(108.dp)
            ) {
                artwork()
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f))
                            )
                        )
                )
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Text(
                        text = game.maxMultiplier,
                        style = TextStyle(
                            fontFamily = OutfitFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        ),
                        color = Color.White,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 10.dp, end = 2.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = game.title,
                        style = TextStyle(
                            fontFamily = OutfitFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp
                        ),
                        color = Color(0xFF334155)
                    )
                    IconButton(
                        onClick = onInfoClick,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "معلومات اللعبة",
                            tint = Color(0xFF1A8EEA),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
