package com.example.ui.screens.games

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dangerous
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GameTopBar
import com.example.ui.components.LtrNumberText
import com.example.ui.components.QuickStakeControlPanel
import com.example.ui.components.formatEgp
import com.example.ui.theme.CrimsonLoss
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.SkyActionBlue
import kotlinx.coroutines.launch
import kotlin.math.pow

@Composable
fun GemsOdysseyScreen(
    balance: Double,
    onPlaceBet: suspend (String, Double) -> Boolean,
    onCreditWin: (String, Double, Double) -> Unit,
    onNavigateDeposit: () -> Unit,
    onBack: () -> Unit
) {
    var stakeText by remember { mutableStateOf("20") }
    var trapCount by remember { mutableIntStateOf(4) }
    var isPlaying by remember { mutableStateOf(false) }
    var activeStake by remember { mutableDoubleStateOf(0.0) }
    var trapIndices by remember { mutableStateOf(emptySet<Int>()) }
    var revealedIndices by remember { mutableStateOf(emptySet<Int>()) }
    var statusText by remember { mutableStateOf("اختر عدد الفخاخ واضغط STAKE للبدء") }
    val scope = rememberCoroutineScope()

    val gemsFound = revealedIndices.count { it !in trapIndices }
    val currentMultiplier = remember(gemsFound, trapCount) {
        if (gemsFound == 0) 1.0
        else {
            val base = 1.0 + (trapCount * 0.08)
            val mult = base.pow(gemsFound.toDouble())
            (kotlin.math.round(mult * 100.0) / 100.0).coerceAtMost(10.0)
        }
    }

    fun startRound() {
        val stake = stakeText.toDoubleOrNull() ?: 0.0
        if (stake <= 0.0 || stake > balance) {
            statusText = "الرصيد غير كافٍ"
            return
        }
        scope.launch {
            if (onPlaceBet("Gems Odyssey", stake)) {
                trapIndices = (0..24).shuffled().take(trapCount).toSet()
                revealedIndices = emptySet()
                activeStake = stake
                isPlaying = true
                statusText = "افتح الجواهر الخضراء وتجنب الفخاخ"
            }
        }
    }

    fun cashout() {
        if (!isPlaying || gemsFound == 0) return
        val payout = activeStake * currentMultiplier
        onCreditWin("Gems Odyssey", payout, currentMultiplier)
        statusText = "ربح محاكاة: +${formatEgp(payout)} ج.م"
        revealedIndices = (0..24).toSet()
        isPlaying = false
        activeStake = 0.0
    }

    fun tapCell(idx: Int) {
        if (!isPlaying || idx in revealedIndices) return
        if (idx in trapIndices) {
            revealedIndices = (0..24).toSet()
            isPlaying = false
            activeStake = 0.0
            statusText = "انفجر الفخ! جرّب جولة جديدة"
        } else {
            revealedIndices = revealedIndices + idx
            if (revealedIndices.size == 25 - trapCount) {
                cashout()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF09122B), Color(0xFF132652), Color(0xFF0A142E))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        GameTopBar(
            balance = balance,
            onBack = onBack,
            onAddFunds = onNavigateDeposit,
            title = "Gems Odyssey",
            darkTheme = true
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(3, 4, 6).forEach { count ->
                    FilterChip(
                        selected = trapCount == count,
                        onClick = { if (!isPlaying) trapCount = count },
                        label = { Text("$count فخاخ") }
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(50),
                color = EmeraldBright.copy(alpha = 0.18f),
                border = BorderStroke(1.dp, EmeraldBright)
            ) {
                LtrNumberText(
                    text = "${String.format("%.2f", currentMultiplier)}x",
                    style = TextStyle(
                        fontFamily = OutfitFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    ),
                    color = GoldAccent,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }

        Text(
            text = statusText,
            style = MaterialTheme.typography.bodyMedium,
            color = Color(0xFFCBD5E1),
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(vertical = 6.dp)
        )

        // 5x5 Gems Grid
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically)
        ) {
            for (r in 0..4) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (c in 0..4) {
                        val idx = r * 5 + c
                        val isRevealed = idx in revealedIndices
                        val isTrap = idx in trapIndices
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(enabled = isPlaying && !isRevealed) { tapCell(idx) },
                            shape = RoundedCornerShape(12.dp),
                            color = when {
                                isRevealed && isTrap -> CrimsonLoss.copy(alpha = 0.25f)
                                isRevealed -> EmeraldBright.copy(alpha = 0.22f)
                                else -> Color(0xFF1D3163)
                            },
                            border = BorderStroke(
                                1.5.dp,
                                when {
                                    isRevealed && isTrap -> CrimsonLoss
                                    isRevealed -> EmeraldBright
                                    else -> Color(0xFF39569E)
                                }
                            )
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (isRevealed) {
                                    Icon(
                                        imageVector = if (isTrap) Icons.Default.Dangerous else Icons.Default.Diamond,
                                        contentDescription = if (isTrap) "فخ" else "جوهرة",
                                        tint = if (isTrap) CrimsonLoss else Color(0xFF00E676),
                                        modifier = Modifier.size(28.dp)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(RoundedCornerShape(50))
                                            .background(Color.White.copy(alpha = 0.16f))
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        val canCashout = isPlaying && gemsFound > 0
        QuickStakeControlPanel(
            stakeText = stakeText,
            onStakeChange = { stakeText = it },
            balance = balance,
            enabled = !isPlaying,
            primaryButtonText = when {
                canCashout -> "TAKE ${formatEgp(activeStake * currentMultiplier)}"
                isPlaying -> "اختر جوهرة"
                else -> "STAKE"
            },
            primaryButtonColor = if (canCashout) EmeraldBright else SkyActionBlue,
            onPrimaryClick = {
                if (canCashout) cashout() else if (!isPlaying) startRound()
            }
        )
    }
}
