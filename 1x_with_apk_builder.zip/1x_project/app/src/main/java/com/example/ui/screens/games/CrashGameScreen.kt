package com.example.ui.screens.games

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.CrashBettingPanel
import com.example.ui.components.GameTopBar
import com.example.ui.components.LtrNumberText
import com.example.ui.components.drawBiplane
import com.example.ui.components.formatEgp
import com.example.ui.theme.CrashArenaBg
import com.example.ui.theme.CrashCardBg
import com.example.ui.theme.CrashOrange
import com.example.ui.theme.CrashPlotBg
import com.example.ui.theme.CrimsonLoss
import com.example.ui.theme.EmeraldBright
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.SkyActionBlue
import com.example.ui.viewmodel.CrashGamePhase
import com.example.ui.viewmodel.CrashRoundHistoryItem
import com.example.ui.viewmodel.CrashUiState
import com.example.ui.viewmodel.CrashViewModel
import com.example.ui.viewmodel.RoundOutcomeType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CrashGameScreen(
    onNavigateDeposit: () -> Unit,
    onBack: () -> Unit,
    crashViewModel: CrashViewModel = viewModel()
) {
    val uiState by crashViewModel.uiState.collectAsStateWithLifecycle()
    val isFlying = uiState.phase == CrashGamePhase.FLYING
    var showHistorySheet by remember { mutableStateOf(false) }

    // Smoothly interpolate flight progress between ViewModel ticks
    val smoothFlightProgress by animateFloatAsState(
        targetValue = if (uiState.phase == CrashGamePhase.IDLE) 0f else uiState.flightProgress,
        animationSpec = tween(durationMillis = 70, easing = LinearEasing),
        label = "flightProgress"
    )

    // Continuous plane hover, tilt sway, and propeller blur animations
    val infiniteTransition = rememberInfiniteTransition(label = "planeMotion")
    val hoverOffsetY by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 480, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hoverOffsetY"
    )
    val propellerScale by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 75, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "propellerScale"
    )
    val thrustAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 220, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "thrustAlpha"
    )

    // Expanding explosion & impact shake when the plane crashes
    val explosionProgress = remember { Animatable(0f) }
    val shakeOffset = remember { Animatable(0f) }
    LaunchedEffect(uiState.phase) {
        if (uiState.phase == CrashGamePhase.CRASHED) {
            explosionProgress.snapTo(0f)
            explosionProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 620, easing = FastOutSlowInEasing)
            )
        } else {
            explosionProgress.snapTo(0f)
        }
    }
    LaunchedEffect(uiState.phase) {
        if (uiState.phase == CrashGamePhase.CRASHED) {
            val offsets = listOf(-10f, 10f, -7f, 7f, -4f, 4f, 0f)
            offsets.forEach { target ->
                shakeOffset.animateTo(target, animationSpec = tween(durationMillis = 45))
            }
        } else {
            shakeOffset.snapTo(0f)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CrashArenaBg)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        GameTopBar(
            balance = uiState.balance,
            onBack = onBack,
            onAddFunds = onNavigateDeposit,
            title = "Crash",
            darkTheme = true
        )

        // Recent crash history chips + History Bottom Sheet button + Preview toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            LazyRow(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(uiState.recentCrashes) { value ->
                    val chipColor = multiplierTierColor(value)
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = chipColor.copy(alpha = 0.18f),
                        border = BorderStroke(1.dp, chipColor.copy(alpha = 0.45f)),
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable { showHistorySheet = true }
                    ) {
                        LtrNumberText(
                            text = String.format(Locale.US, "%.2fx", value),
                            style = TextStyle(
                                fontFamily = OutfitFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            ),
                            color = chipColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            // History Sheet Trigger Button
            Surface(
                shape = RoundedCornerShape(50),
                color = CrashCardBg,
                border = BorderStroke(1.dp, SkyActionBlue.copy(alpha = 0.7f)),
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable { showHistorySheet = true }
                    .testTag("crash_history_sheet_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "سجل النتائج",
                        tint = SkyActionBlue,
                        modifier = Modifier.size(15.dp)
                    )
                    Text(
                        text = "السجل (${uiState.roundHistory.size})",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Preview Toggle
            Surface(
                shape = RoundedCornerShape(50),
                color = CrashCardBg,
                border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.7f)),
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable { crashViewModel.toggleCrashPreview() }
                    .testTag("crash_preview_toggle")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(
                        imageVector = if (uiState.showCrashPreview) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = "تبديل معاينة المحاكاة",
                        tint = GoldAccent,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (uiState.showCrashPreview) "العداد ظاهر" else "إظهار العداد",
                        style = MaterialTheme.typography.labelSmall,
                        color = GoldAccent,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Crash Deduction & Countdown Counter Bar
        if (uiState.showCrashPreview) {
            val isDangerZone = isFlying && uiState.remainingCrashSeconds <= 1.5
            val counterAccent = when {
                isDangerZone -> CrimsonLoss
                isFlying -> CrashOrange
                else -> GoldAccent
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .testTag("crash_predictor_counter"),
                shape = RoundedCornerShape(14.dp),
                color = CrashCardBg,
                border = BorderStroke(1.dp, counterAccent.copy(alpha = 0.65f))
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "عداد استنتاج موعد السقوط",
                                tint = counterAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (isFlying) "متبقي للسقوط:" else "استنتاج موعد السقوط:",
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White
                            )
                            LtrNumberText(
                                text = String.format(Locale.US, "%.1fs", uiState.remainingCrashSeconds),
                                style = TextStyle(
                                    fontFamily = OutfitFontFamily,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp
                                ),
                                color = counterAccent
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(50),
                            color = counterAccent.copy(alpha = 0.16f)
                        ) {
                            Text(
                                text = String.format(Locale.US, "ستنفجر عند: %.2fx", uiState.crashPoint),
                                style = MaterialTheme.typography.labelSmall,
                                color = counterAccent,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    LinearProgressIndicator(
                        progress = { if (isFlying) uiState.crashCountdownProgress else 0f },
                        color = counterAccent,
                        trackColor = Color.White.copy(alpha = 0.1f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(5.dp)
                            .clip(RoundedCornerShape(50))
                    )
                }
            }
        }

        // Flight Plot Canvas Card
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(204.dp)
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .graphicsLayer {
                    translationX = shakeOffset.value
                    translationY = shakeOffset.value * 0.4f
                },
            shape = RoundedCornerShape(18.dp),
            color = CrashPlotBg
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val startX = w * 0.08f
                    val startY = h * 0.84f

                    if (uiState.phase != CrashGamePhase.IDLE) {
                        val t = smoothFlightProgress.coerceIn(0.02f, 0.96f)
                        val bob = if (isFlying) hoverOffsetY else 0f
                        val endX = startX + (w * 0.72f) * t
                        val endY = (startY - (h * 0.62f) * (t.pow(1.35f))) + bob

                        val path = Path().apply {
                            moveTo(startX, startY)
                            quadraticTo(
                                startX + (endX - startX) * 0.55f,
                                startY,
                                endX,
                                endY
                            )
                        }
                        drawPath(
                            path = path,
                            brush = Brush.horizontalGradient(
                                colors = if (uiState.phase == CrashGamePhase.CRASHED) {
                                    listOf(CrimsonLoss.copy(alpha = 0.4f), CrimsonLoss)
                                } else {
                                    listOf(Color(0xFFFF8F00), GoldAccent)
                                }
                            ),
                            style = Stroke(width = 9f, cap = StrokeCap.Round)
                        )

                        if (uiState.phase == CrashGamePhase.CRASHED) {
                            val exp = explosionProgress.value
                            val center = Offset(endX, endY)
                            val shockRadius = 20f + 95f * exp
                            val shockAlpha = (1f - exp).coerceIn(0f, 1f)

                            // Expanding shockwave ring
                            drawCircle(
                                color = GoldAccent.copy(alpha = shockAlpha * 0.85f),
                                radius = shockRadius,
                                center = center,
                                style = Stroke(width = (10f * (1f - exp)).coerceAtLeast(2f))
                            )

                            // Fiery core flash
                            val coreRadius = 26f + 44f * (1f - (exp * 0.5f))
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = shockAlpha),
                                        GoldAccent.copy(alpha = shockAlpha * 0.9f),
                                        CrimsonLoss.copy(alpha = shockAlpha * 0.75f),
                                        Color.Transparent
                                    ),
                                    center = center,
                                    radius = coreRadius
                                ),
                                radius = coreRadius,
                                center = center
                            )

                            // Radial explosion debris sparks
                            val sparkCount = 12
                            for (i in 0 until sparkCount) {
                                val angleRad = (i * (360f / sparkCount)) * (Math.PI / 180.0)
                                val dist = 16f + 88f * exp
                                val sx = center.x + (dist * cos(angleRad)).toFloat()
                                val sy = center.y + (dist * sin(angleRad)).toFloat()
                                drawCircle(
                                    color = if (i % 2 == 0) GoldAccent.copy(alpha = shockAlpha) else CrimsonLoss.copy(alpha = shockAlpha),
                                    radius = (7f * (1f - exp * 0.7f)).coerceAtLeast(2f),
                                    center = Offset(sx, sy)
                                )
                            }
                        } else {
                            drawBiplane(
                                center = Offset(endX, endY),
                                scale = 1.05f,
                                angleDeg = -20f - (t * 14f) + (bob * 0.6f),
                                propellerScale = propellerScale,
                                thrustAlpha = thrustAlpha
                            )
                        }
                    } else {
                        drawBiplane(
                            center = Offset(startX + 18f, startY - 12f + hoverOffsetY * 0.4f),
                            scale = 1.0f,
                            angleDeg = -8f,
                            propellerScale = propellerScale,
                            thrustAlpha = 0.35f
                        )
                    }
                }

                // Live Multiplier Readout
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(18.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    LtrNumberText(
                        text = String.format(Locale.US, "%.2fx", uiState.multiplier),
                        style = TextStyle(
                            fontFamily = OutfitFontFamily,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 38.sp
                        ),
                        color = when (uiState.phase) {
                            CrashGamePhase.CRASHED -> CrimsonLoss
                            CrashGamePhase.CASHED_OUT -> EmeraldBright
                            else -> Color.White
                        },
                        modifier = Modifier.testTag("crash_multiplier_text")
                    )
                }

                // Status Pill
                Surface(
                    color = Color.Black.copy(alpha = 0.58f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                ) {
                    Text(
                        text = uiState.statusMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        color = when (uiState.phase) {
                            CrashGamePhase.CRASHED -> Color(0xFFFF8A80)
                            CrashGamePhase.CASHED_OUT -> EmeraldBright
                            else -> GoldAccent
                        },
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        CrashBettingPanel(
            uiState = uiState,
            onStakeChange = crashViewModel::onStakeChange,
            onSelectQuickStake = crashViewModel::selectQuickStake,
            onMinStake = crashViewModel::setMinStake,
            onHalveStake = crashViewModel::halveStake,
            onDoubleStake = crashViewModel::doubleStake,
            onMaxStake = crashViewModel::setMaxStake,
            onStartRound = crashViewModel::startSimulation,
            onCashOut = crashViewModel::cashOut,
            onNavigateDeposit = onNavigateDeposit,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        // Live Simulated Players Table
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("USER", color = Color(0xFF8C9BB0), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1.2f))
                    Text("ODDS", color = Color(0xFF8C9BB0), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(0.9f), textAlign = TextAlign.Center)
                    Text("BET", color = Color(0xFF8C9BB0), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    Text("WIN", color = Color(0xFF8C9BB0), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                }
                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    items(uiState.bots) { bot ->
                        val winVal = if (bot.cashedOut) bot.bet * bot.targetOdds else 0.0
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = bot.user,
                                color = Color.White,
                                fontSize = 14.sp,
                                modifier = Modifier.weight(1.2f)
                            )
                            Text(
                                text = if (bot.cashedOut) String.format(Locale.US, "%.2fx", bot.targetOdds) else "-",
                                color = if (bot.cashedOut) EmeraldBright else Color(0xFF8C9BB0),
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(0.9f)
                            )
                            Text(
                                text = "${bot.bet} ج.م",
                                color = Color.White,
                                fontSize = 14.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = if (bot.cashedOut) String.format(Locale.US, "%.1f", winVal) else "-",
                                color = if (bot.cashedOut) GoldAccent else Color(0xFF8C9BB0),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.End,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showHistorySheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showHistorySheet = false },
            sheetState = sheetState,
            containerColor = CrashArenaBg,
            contentColor = Color.White
        ) {
            CrashMultiplierHistorySheetContent(uiState = uiState)
        }
    }
}

private fun multiplierTierColor(multiplier: Double): Color = when {
    multiplier >= 10.0 -> GoldAccent
    multiplier >= 3.0 -> EmeraldBright
    multiplier >= 1.5 -> SkyActionBlue
    else -> CrimsonLoss
}

@Composable
private fun CrashMultiplierHistorySheetContent(uiState: CrashUiState) {
    val playerRounds = remember(uiState.roundHistory) {
        uiState.roundHistory.filter { it.outcomeType != RoundOutcomeType.SIMULATED_FEED }
    }
    val winCount = remember(playerRounds) {
        playerRounds.count { it.outcomeType == RoundOutcomeType.WIN }
    }
    val winRate = if (playerRounds.isEmpty()) 0 else (winCount * 100) / playerRounds.size
    val peakMultiplier = remember(uiState.roundHistory) {
        uiState.roundHistory.maxOfOrNull { it.crashMultiplier } ?: 0.0
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 18.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "سجل نتائج الجولات والمضاعفات",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Text(
                    text = "تتبّع تطور نتائجك والمضاعفات السابقة",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF94A3B8)
                )
            }
            Surface(
                shape = CircleShape,
                color = GoldAccent.copy(alpha = 0.16f),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = GoldAccent
                    )
                }
            }
        }

        // Progression Stats Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ProgressionStatTile(
                label = "أفضل سحب لك",
                value = if (uiState.bestCashedMultiplier > 0.0) {
                    String.format(Locale.US, "%.2fx", uiState.bestCashedMultiplier)
                } else {
                    String.format(Locale.US, "%.2fx", peakMultiplier)
                },
                accent = GoldAccent,
                modifier = Modifier.weight(1f)
            )
            ProgressionStatTile(
                label = "السلسلة الحالية",
                value = "${uiState.currentWinStreak}",
                accent = CrashOrange,
                icon = Icons.Default.LocalFireDepartment,
                modifier = Modifier.weight(1f)
            )
            ProgressionStatTile(
                label = "نسبة الفوز",
                value = "$winRate%",
                accent = EmeraldBright,
                modifier = Modifier.weight(1f)
            )
        }

        HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(uiState.roundHistory, key = { "${it.roundNumber}_${it.timestamp}" }) { item ->
                HistoryRoundRow(item = item)
            }
        }
    }
}

@Composable
private fun ProgressionStatTile(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = CrashCardBg,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(16.dp)
                    )
                }
                LtrNumberText(
                    text = value,
                    style = TextStyle(
                        fontFamily = OutfitFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    ),
                    color = accent
                )
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF94A3B8)
            )
        }
    }
}

@Composable
private fun HistoryRoundRow(item: CrashRoundHistoryItem) {
    val tierColor = multiplierTierColor(item.crashMultiplier)
    val timeText = remember(item.timestamp) {
        SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(item.timestamp))
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = CrashCardBg,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Round Number Badge
            Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.08f),
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    LtrNumberText(
                        text = "#${item.roundNumber}",
                        style = TextStyle(
                            fontFamily = OutfitFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        ),
                        color = Color(0xFFCBD5E1)
                    )
                }
            }

            // Outcome summary
            Column(modifier = Modifier.weight(1f)) {
                when (item.outcomeType) {
                    RoundOutcomeType.WIN -> {
                        Text(
                            text = "سحب ناجح عند ${String.format(Locale.US, "%.2fx", item.cashedOutAt ?: 1.0)}",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldBright
                        )
                        Text(
                            text = "الربح: +${formatEgp(item.payout)} ج.م • $timeText",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    RoundOutcomeType.CRASHED -> {
                        Text(
                            text = "انفجار قبل السحب",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = CrimsonLoss
                        )
                        Text(
                            text = "الرهان: -${formatEgp(item.stake)} ج.م • $timeText",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    RoundOutcomeType.SIMULATED_FEED -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FlightTakeoff,
                                contentDescription = null,
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "جولة سابقة في السجل",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFFCBD5E1)
                            )
                        }
                        Text(
                            text = timeText,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            // Crash Multiplier Pill
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = tierColor.copy(alpha = 0.16f),
                border = BorderStroke(1.dp, tierColor.copy(alpha = 0.55f))
            ) {
                LtrNumberText(
                    text = String.format(Locale.US, "%.2fx", item.crashMultiplier),
                    style = TextStyle(
                        fontFamily = OutfitFontFamily,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp
                    ),
                    color = tierColor,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }
}
