package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun LoginSportyHeader(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.background(Color.White)) {
        val w = size.width
        val h = size.height

        // Soft light blue-gray curved backdrop matching Screenshot 5
        val skyCurve = Path().apply {
            moveTo(0f, 0f)
            lineTo(w, 0f)
            lineTo(w, h * 0.72f)
            quadraticTo(w * 0.5f, h * 0.96f, 0f, h * 0.86f)
            close()
        }
        drawPath(
            path = skyCurve,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFEDF2F7), Color(0xFFF5F7FA))
            )
        )

        // Red diagonal curved sphere on left
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFFE53935), Color(0xFFB71C1C))
            ),
            radius = w * 0.34f,
            center = Offset(w * 0.22f, h * 0.04f)
        )
        drawArc(
            color = Color.White.copy(alpha = 0.22f),
            startAngle = 10f,
            sweepAngle = 115f,
            useCenter = false,
            topLeft = Offset(w * -0.06f, h * -0.34f),
            size = Size(w * 0.54f, w * 0.54f),
            style = Stroke(width = 20f)
        )

        // Royal blue curved sphere on right
        drawCircle(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF1E88E5), Color(0xFF1565C0))
            ),
            radius = w * 0.43f,
            center = Offset(w * 0.82f, h * 0.08f)
        )
        drawArc(
            color = Color.White.copy(alpha = 0.2f),
            startAngle = 135f,
            sweepAngle = 95f,
            useCenter = false,
            topLeft = Offset(w * 0.45f, h * -0.28f),
            size = Size(w * 0.72f, w * 0.72f),
            style = Stroke(width = 24f)
        )

        // Central 3D shaded baseball / sports ball
        val ballCenter = Offset(w * 0.54f, h * 0.46f)
        val ballRadius = h * 0.28f
        drawCircle(
            color = Color.Black.copy(alpha = 0.14f),
            radius = ballRadius * 1.03f,
            center = ballCenter.copy(y = ballCenter.y + 10f)
        )
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFFFFFF), Color(0xFFD5DFEC), Color(0xFF91A6BF)),
                center = Offset(ballCenter.x - ballRadius * 0.3f, ballCenter.y - ballRadius * 0.3f),
                radius = ballRadius * 1.65f
            ),
            radius = ballRadius,
            center = ballCenter
        )
        drawArc(
            color = Color(0xFF7B8FA6),
            startAngle = -55f,
            sweepAngle = 110f,
            useCenter = false,
            topLeft = Offset(ballCenter.x - ballRadius * 1.35f, ballCenter.y - ballRadius * 0.7f),
            size = Size(ballRadius * 1.4f, ballRadius * 1.4f),
            style = Stroke(width = 3.5f)
        )
        drawArc(
            color = Color(0xFF7B8FA6),
            startAngle = 125f,
            sweepAngle = 110f,
            useCenter = false,
            topLeft = Offset(ballCenter.x - ballRadius * 0.05f, ballCenter.y - ballRadius * 0.7f),
            size = Size(ballRadius * 1.4f, ballRadius * 1.4f),
            style = Stroke(width = 3.5f)
        )
    }
}

fun DrawScope.drawBiplane(
    center: Offset,
    scale: Float,
    angleDeg: Float,
    propellerScale: Float = 1f,
    thrustAlpha: Float = 0.55f
) {
    rotate(degrees = angleDeg, pivot = center) {
        val s = scale
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFFD54F).copy(alpha = thrustAlpha), Color.Transparent),
                center = Offset(center.x - 24f * s, center.y + 4f * s),
                radius = 34f * s
            ),
            radius = 34f * s,
            center = Offset(center.x - 24f * s, center.y + 4f * s)
        )

        val bodyPath = Path().apply {
            moveTo(center.x - 28f * s, center.y - 4f * s)
            lineTo(center.x + 22f * s, center.y - 10f * s)
            quadraticTo(center.x + 34f * s, center.y - 6f * s, center.x + 32f * s, center.y + 6f * s)
            lineTo(center.x - 24f * s, center.y + 8f * s)
            close()
        }
        drawPath(
            path = bodyPath,
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFFFFE082), Color(0xFFFF9800))
            )
        )

        val tail = Path().apply {
            moveTo(center.x - 28f * s, center.y - 2f * s)
            lineTo(center.x - 34f * s, center.y - 16f * s)
            lineTo(center.x - 18f * s, center.y - 6f * s)
            close()
        }
        drawPath(tail, color = Color(0xFFFFB300))

        drawRoundRect(
            color = Color(0xFFFFD54F),
            topLeft = Offset(center.x - 4f * s, center.y - 18f * s),
            size = Size(26f * s, 7f * s),
            cornerRadius = CornerRadius(4f * s)
        )
        drawRoundRect(
            color = Color(0xFFF57C00),
            topLeft = Offset(center.x - 2f * s, center.y + 6f * s),
            size = Size(22f * s, 6f * s),
            cornerRadius = CornerRadius(4f * s)
        )

        drawCircle(
            color = Color(0xFF1F2937),
            radius = 5.5f * s,
            center = Offset(center.x + 2f * s, center.y - 8f * s)
        )

        val propHalf = (18f * s * propellerScale).coerceAtLeast(4f * s)
        drawLine(
            color = Color(0xFFFFF8E1),
            start = Offset(center.x + 34f * s, center.y - propHalf),
            end = Offset(center.x + 34f * s, center.y + propHalf),
            strokeWidth = 4f * s,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun CrashBannerArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF20183A), Color(0xFF472146), Color(0xFF7D2E35))
            )
        )
        // Distant mountains silhouette at bottom
        val mountains = Path().apply {
            moveTo(0f, h)
            lineTo(0f, h * 0.74f)
            lineTo(w * 0.22f, h * 0.56f)
            lineTo(w * 0.44f, h * 0.72f)
            lineTo(w * 0.68f, h * 0.52f)
            lineTo(w, h * 0.68f)
            lineTo(w, h)
            close()
        }
        drawPath(mountains, color = Color(0xFF161129).copy(alpha = 0.65f))

        // Upper flight arc + large golden biplane (matching Screenshot 1)
        val topTrail = Path().apply {
            moveTo(0f, h * 0.25f)
            quadraticTo(w * 0.30f, h * 0.34f, w * 0.50f, h * 0.16f)
        }
        drawPath(
            path = topTrail,
            brush = Brush.horizontalGradient(
                colors = listOf(Color.Transparent, Color(0xFFFFB300), Color(0xFFFFEE58))
            ),
            style = Stroke(width = 12f, cap = StrokeCap.Round)
        )
        drawBiplane(center = Offset(w * 0.53f, h * 0.16f), scale = 1.32f, angleDeg = -22f, thrustAlpha = 0.7f)

        // Lower golden flight trail + second smaller biplane
        val bottomTrail = Path().apply {
            moveTo(w * 0.54f, h * 0.86f)
            quadraticTo(w * 0.76f, h * 0.88f, w * 0.98f, h * 0.82f)
        }
        drawPath(
            path = bottomTrail,
            brush = Brush.horizontalGradient(
                colors = listOf(Color(0xFFFFD54F), Color(0xFFFF9800).copy(alpha = 0.4f))
            ),
            style = Stroke(width = 8f, cap = StrokeCap.Round)
        )
        drawBiplane(center = Offset(w * 0.55f, h * 0.82f), scale = 0.92f, angleDeg = -10f, thrustAlpha = 0.45f)
    }
}

@Composable
fun AppleFortuneBannerArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF5EA63D), Color(0xFF1B4D27), Color(0xFF0A1D12)),
                center = Offset(w * 0.5f, h * 0.45f),
                radius = w * 0.68f
            )
        )
        // Golden forest sunbeams
        for (i in -4..4) {
            drawLine(
                color = Color(0xFFFFF59D).copy(alpha = 0.18f),
                start = Offset(w * 0.5f, h * 0.48f),
                end = Offset(w * (0.5f + i * 0.16f), 0f),
                strokeWidth = 34f
            )
        }
        // Fireflies
        for (i in 0..10) {
            val fx = ((i * 89 + 23) % 92 + 4) / 100f * w
            val fy = ((i * 53 + 17) % 80 + 8) / 100f * h
            drawCircle(Color(0xFFFFF176).copy(alpha = 0.65f), radius = 3.5f, center = Offset(fx, fy))
        }
        // Tilted purple poison flask (left)
        rotate(-20f, pivot = Offset(w * 0.34f, h * 0.65f)) {
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFFE1BEE7), Color(0xFF8E24AA))),
                topLeft = Offset(w * 0.28f, h * 0.42f),
                size = Size(w * 0.12f, h * 0.44f),
                cornerRadius = CornerRadius(22f)
            )
            drawRoundRect(
                color = Color(0xFF8D6E63),
                topLeft = Offset(w * 0.315f, h * 0.34f),
                size = Size(w * 0.05f, h * 0.10f),
                cornerRadius = CornerRadius(8f)
            )
        }
        // Tilted blue elixir flask (right)
        rotate(18f, pivot = Offset(w * 0.66f, h * 0.65f)) {
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFFB3E5FC), Color(0xFF0288D1))),
                topLeft = Offset(w * 0.60f, h * 0.44f),
                size = Size(w * 0.12f, h * 0.42f),
                cornerRadius = CornerRadius(22f)
            )
            drawRoundRect(
                color = Color(0xFF8D6E63),
                topLeft = Offset(w * 0.635f, h * 0.36f),
                size = Size(w * 0.05f, h * 0.10f),
                cornerRadius = CornerRadius(8f)
            )
        }
        // Giant glossy Red Apple center
        val appleCenter = Offset(w * 0.5f, h * 0.55f)
        val appleR = h * 0.34f
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFF6E6E), Color(0xFFE50914), Color(0xFF7B0000)),
                center = Offset(appleCenter.x - appleR * 0.32f, appleCenter.y - appleR * 0.32f),
                radius = appleR * 1.45f
            ),
            radius = appleR,
            center = appleCenter
        )
        // Stem + vibrant leaf
        drawLine(
            color = Color(0xFF5D4037),
            start = Offset(appleCenter.x, appleCenter.y - appleR * 0.85f),
            end = Offset(appleCenter.x + 6f, appleCenter.y - appleR * 1.25f),
            strokeWidth = 8f,
            cap = StrokeCap.Round
        )
        val leaf = Path().apply {
            moveTo(appleCenter.x, appleCenter.y - appleR * 0.92f)
            quadraticTo(appleCenter.x + appleR * 0.65f, appleCenter.y - appleR * 1.5f, appleCenter.x + appleR * 0.72f, appleCenter.y - appleR * 0.86f)
            quadraticTo(appleCenter.x + appleR * 0.3f, appleCenter.y - appleR * 0.65f, appleCenter.x, appleCenter.y - appleR * 0.92f)
        }
        drawPath(leaf, color = Color(0xFF66BB6A))
        drawCircle(
            color = Color.White.copy(alpha = 0.5f),
            radius = appleR * 0.22f,
            center = Offset(appleCenter.x - appleR * 0.36f, appleCenter.y - appleR * 0.34f)
        )
    }
}

@Composable
fun GemsOdysseyBannerArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF0A1432), Color(0xFF17366B), Color(0xFF0A183D))
            )
        )
        // Horizontal laser speed streaks
        for (i in 1..4) {
            drawLine(
                color = Color(0xFF38BDF8).copy(alpha = 0.2f),
                start = Offset(0f, h * (i * 0.2f)),
                end = Offset(w, h * (i * 0.2f)),
                strokeWidth = 3f
            )
        }
        val gems = listOf(
            Triple(Offset(w * 0.22f, h * 0.38f), Color(0xFFEC4899), h * 0.14f),
            Triple(Offset(w * 0.38f, h * 0.28f), Color(0xFF22C55E), h * 0.18f),
            Triple(Offset(w * 0.58f, h * 0.26f), Color(0xFF22C55E), h * 0.17f),
            Triple(Offset(w * 0.45f, h * 0.58f), Color(0xFF4ADE80), h * 0.20f),
            Triple(Offset(w * 0.66f, h * 0.62f), Color(0xFF22C55E), h * 0.19f),
            Triple(Offset(w * 0.80f, h * 0.36f), Color(0xFFF59E0B), h * 0.15f),
            Triple(Offset(w * 0.26f, h * 0.74f), Color(0xFF22C55E), h * 0.16f)
        )
        gems.forEach { (pos, col, r) ->
            val path = Path().apply {
                moveTo(pos.x, pos.y - r)
                lineTo(pos.x + r * 0.9f, pos.y - r * 0.22f)
                lineTo(pos.x + r * 0.55f, pos.y + r * 0.88f)
                lineTo(pos.x - r * 0.55f, pos.y + r * 0.88f)
                lineTo(pos.x - r * 0.9f, pos.y - r * 0.22f)
                close()
            }
            drawPath(path, color = col)
            drawPath(path, color = Color.White.copy(alpha = 0.65f), style = Stroke(width = 2.5f))
        }
    }
}

@Composable
fun RoyalHiLoBannerArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFC2185B), Color(0xFF6A1B9A), Color(0xFF1F0D35)),
                center = Offset(w * 0.5f, h * 0.48f),
                radius = w * 0.72f
            )
        )
        // Golden swirl halo
        drawCircle(
            color = Color(0xFFFFD54F).copy(alpha = 0.45f),
            radius = h * 0.45f,
            center = Offset(w * 0.5f, h * 0.52f),
            style = Stroke(width = 7f)
        )
        // Fanned playing cards matching Screenshot 1
        val angles = listOf(-32f, -18f, -5f, 8f, 22f, 34f)
        angles.forEachIndexed { idx, deg ->
            rotate(deg, pivot = Offset(w * 0.52f, h * 0.78f)) {
                drawRoundRect(
                    color = if (idx == angles.lastIndex) Color(0xFFFFFFFF) else Color(0xFFF8FAFC),
                    topLeft = Offset(w * 0.40f, h * 0.14f),
                    size = Size(w * 0.24f, h * 0.62f),
                    cornerRadius = CornerRadius(10f)
                )
                drawRoundRect(
                    color = Color(0xFFCBD5E1),
                    topLeft = Offset(w * 0.40f, h * 0.14f),
                    size = Size(w * 0.24f, h * 0.62f),
                    cornerRadius = CornerRadius(10f),
                    style = Stroke(width = 2f)
                )
            }
        }
        // Golden coins
        drawCircle(Color(0xFFFFCA28), radius = h * 0.12f, center = Offset(w * 0.18f, h * 0.34f))
        drawCircle(Color(0xFFFFCA28), radius = h * 0.11f, center = Offset(w * 0.84f, h * 0.68f))
    }
}

@Composable
fun MundialBannerArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF039BE5), Color(0xFF4FC3F7), Color(0xFF43A047))
            )
        )
        drawRect(
            color = Color(0xFF2E7D32),
            topLeft = Offset(0f, h * 0.66f),
            size = Size(w, h * 0.34f)
        )
        // Red & blue stadium ribbons
        drawCircle(Color(0xFFE53935).copy(alpha = 0.8f), radius = h * 0.16f, center = Offset(w * 0.24f, h * 0.30f))
        drawCircle(Color(0xFF1E88E5).copy(alpha = 0.8f), radius = h * 0.16f, center = Offset(w * 0.76f, h * 0.30f))
        // Soccer ball
        val c = Offset(w * 0.5f, h * 0.32f)
        val r = h * 0.25f
        drawCircle(Color.White, radius = r, center = c)
        drawCircle(Color(0xFF1E293B), radius = r * 0.34f, center = c)
        for (i in 0..4) {
            val a = i * 72f * (Math.PI / 180.0)
            drawCircle(
                color = Color(0xFF1E293B),
                radius = r * 0.22f,
                center = Offset(
                    c.x + (r * 0.72f * cos(a)).toFloat(),
                    c.y + (r * 0.72f * sin(a)).toFloat()
                )
            )
        }
        // Red round button detail at bottom matching Screenshot 1
        drawCircle(Color(0xFFD32F2F), radius = h * 0.16f, center = Offset(w * 0.52f, h * 0.82f))
    }
}

@Composable
fun FourAcesBannerArt(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        drawRect(
            brush = Brush.linearGradient(
                colors = listOf(Color(0xFF2E1226), Color(0xFF6B1E32), Color(0xFF1C2342))
            )
        )
        for (i in 0..3) {
            val xOff = w * (0.20f + i * 0.15f)
            val yOff = h * (0.18f + (if (i % 2 == 0) 0f else 0.08f))
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(xOff, yOff),
                size = Size(w * 0.18f, h * 0.52f),
                cornerRadius = CornerRadius(8f)
            )
            drawCircle(
                color = if (i % 2 == 0) Color(0xFFD32F2F) else Color(0xFF1E293B),
                radius = w * 0.033f,
                center = Offset(xOff + w * 0.09f, yOff + h * 0.26f)
            )
        }
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFFB300).copy(alpha = 0.7f), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.54f),
                radius = h * 0.36f
            ),
            radius = h * 0.36f,
            center = Offset(w * 0.5f, h * 0.54f)
        )
    }
}
